from resources.lib.indexers import simkl_auth_guard
from resources.lib.modules.globals import g


class Menus:
    @staticmethod
    def home(*, write_kodi_cache: bool = False):
        from resources.lib.simkl.playback_history import add_watch_history_home_item

        g.add_directory_item(
            g.get_language_string(30000),
            action='moviesHome',
            description=g.get_language_string(30364),
            menu_item=g.create_icon_dict("movies", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30002),
            action='showsHome',
            description=g.get_language_string(30365),
            menu_item=g.create_icon_dict("shows", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30658),  # "Discover Anime"
            action='discoverAnime',
            description=g.get_language_string(30659),
            menu_item=g.create_icon_dict("anime", g.ICONS_PATH),
        )
        add_watch_history_home_item()
        signed_in = bool(g.get_setting('simkl.auth'))
        from resources.lib.simkl.menu_parent_refresh import note_home_menu_built

        note_home_menu_built(signed_in=signed_in)
        if signed_in:
            g.add_directory_item(
                g.get_language_string(30001),
                action='myMovies',
                description=g.get_language_string(30366),
                menu_item=g.create_icon_dict("movies_simkl", g.ICONS_PATH),
            )
            g.add_directory_item(
                g.get_language_string(30003),
                action='myShows',
                description=g.get_language_string(30367),
                menu_item=g.create_icon_dict("shows_simkl", g.ICONS_PATH),
            )
            g.add_directory_item(
                g.get_language_string(30737),
                action='myAnime',
                description=g.get_language_string(30738),
                menu_item=g.create_icon_dict("anime_simkl", g.ICONS_PATH),
            )
        if g.my_files_available():
            g.add_directory_item(
                g.get_language_string(30173),
                action='myFiles',
                description=g.get_language_string(30368),
                menu_item=g.create_icon_dict("cloud_files", g.ICONS_PATH),
            )
        g.add_directory_item(
            g.get_language_string(30013),
            action='searchMenu',
            description=g.get_language_string(30369),
            menu_item=g.create_icon_dict("search", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30027),
            action='toolsMenu',
            description=g.get_language_string(30370),
            menu_item=g.create_icon_dict("tools", g.ICONS_PATH),
        )
        if write_kodi_cache:
            g.close_directory(g.CONTENT_MENU, cache=True)
        else:
            g.close_directory(g.CONTENT_MENU)

    @staticmethod
    def search_menu():
        from resources.lib.meta.provider_settings import tmdb_features_enabled

        if g.get_bool_setting('searchHistory'):
            g.add_directory_item(
                g.get_language_string(31236),
                action='allSearchHistory',
                description=g.get_language_string(31238),
                menu_item=g.create_icon_dict("search", g.ICONS_PATH),
            )
            g.add_directory_item(
                g.get_language_string(30025),
                action='moviesSearchHistory',
                description=g.get_language_string(30373),
                menu_item=g.create_icon_dict("movies_search", g.ICONS_PATH),
            )
            g.add_directory_item(
                g.get_language_string(30026),
                action='showsSearchHistory',
                description=g.get_language_string(30374),
                menu_item=g.create_icon_dict("shows_search", g.ICONS_PATH),
            )
            g.add_directory_item(
                g.get_language_string(30769),
                action='animeSearchHistory',
                description=g.get_language_string(31040),
                menu_item=g.create_icon_dict("anime_search", g.ICONS_PATH),
            )
            if tmdb_features_enabled():
                g.add_directory_item(
                    g.get_language_string(30327),
                    action='actorSearchHistory',
                    description=g.get_language_string(30777),
                    menu_item=g.create_icon_dict("actor_search", g.ICONS_PATH),
                )
        else:
            g.add_directory_item(
                g.get_language_string(31236),
                action='allSearch',
                description=g.get_language_string(31237),
                menu_item=g.create_icon_dict("search", g.ICONS_PATH),
            )
            g.add_directory_item(
                g.get_language_string(30025),
                action='moviesSearch',
                description=g.get_language_string(30371),
                menu_item=g.create_icon_dict("movies_search", g.ICONS_PATH),
            )
            g.add_directory_item(
                g.get_language_string(30026),
                action='showsSearch',
                description=g.get_language_string(30372),
                menu_item=g.create_icon_dict("shows_search", g.ICONS_PATH),
            )
            g.add_directory_item(
                g.get_language_string(30769),
                action='animeSearch',
                description=g.get_language_string(30770),
                menu_item=g.create_icon_dict("anime_search", g.ICONS_PATH),
            )
            if tmdb_features_enabled():
                g.add_directory_item(
                    g.get_language_string(30327),
                    action='searchByActor',
                    description=g.get_language_string(30776),
                    menu_item=g.create_icon_dict("actor_search", g.ICONS_PATH),
                )
        g.close_directory(g.CONTENT_MENU, cache=False)

    @staticmethod
    def tools_menu():
        g.add_directory_item(
            g.get_language_string(31445),
            action="widgetTools",
            description=g.get_language_string(31446),
            menu_item=g.create_icon_dict("list", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(31232),
            action="showReleaseNotes",
            is_folder=False,
            description=g.get_language_string(31233),
            menu_item=g.create_icon_dict("tools", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30037),
            action='providerTools',
            description=g.get_language_string(30377),
            menu_item=g.create_icon_dict("tools", g.ICONS_PATH),
        )
        if g.debrid_available():
            g.add_directory_item(
                g.get_language_string(30038),
                action='debridServices',
                description=g.get_language_string(30378),
                menu_item=g.create_icon_dict("cloud", g.ICONS_PATH),
            )
        g.add_directory_item(
            g.get_language_string(30028),
            action='clearCache',
            is_folder=False,
            description=g.get_language_string(30379),
            menu_item=g.create_icon_dict("clear_cache", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30039),
            action='clearTorrentCache',
            is_folder=False,
            description=g.get_language_string(30380),
            menu_item=g.create_icon_dict("clear_cache", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30180),
            action='clearSearchHistory',
            is_folder=False,
            description=g.get_language_string(30381),
            menu_item=g.create_icon_dict("clear_search", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30040),
            action='openSettings',
            is_folder=False,
            description=g.get_language_string(30382),
            menu_item=g.create_icon_dict("settings", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30041),
            action='cleanInstall',
            is_folder=False,
            description=g.get_language_string(30383),
            menu_item=g.create_icon_dict("clear", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30215),
            action='simklSyncTools',
            is_folder=True,
            description=g.get_language_string(30384),
            menu_item=g.create_icon_dict("simkl", g.ICONS_PATH),
        )
        g.add_directory_item(
            'Download Manager',
            action='downloadManagerView',
            is_folder=False,
            description='View Current Downloads',
            menu_item=g.create_icon_dict("download", g.ICONS_PATH),
        )
        if g.get_bool_setting("skin.testmenu", False):
            g.add_directory_item(
                'Window Tests',
                action='testWindows',
                description=g.get_language_string(30385),
                menu_item=g.create_icon_dict("test", g.ICONS_PATH),
            )
        g.close_directory(g.CONTENT_MENU)

    @staticmethod
    def provider_menu():
        g.add_directory_item(
            g.get_language_string(30139),
            action='manualProviderUpdate',
            is_folder=False,
            description=g.get_language_string(30386),
            menu_item=g.create_icon_dict("providers_update", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30140),
            action='manageProviders',
            is_folder=False,
            description=g.get_language_string(30387),
            menu_item=g.create_icon_dict("providers", g.ICONS_PATH),
        )
        g.close_directory(g.CONTENT_MENU)

    @staticmethod
    @simkl_auth_guard
    def simkl_sync_tools():
        g.add_directory_item(
            g.get_language_string(30216),
            action='flushSimklActivities',
            is_folder=False,
            description=g.get_language_string(30388),
            menu_item=g.create_icon_dict("simkl_reset", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30217),
            action='forceSimklSync',
            is_folder=False,
            description=g.get_language_string(30389),
            menu_item=g.create_icon_dict("simkl_sync", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(31133),
            action='warmEpisodeMenus',
            is_folder=False,
            description=g.get_language_string(31134),
            menu_item=g.create_icon_dict("simkl_sync", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30218),
            action='rebuildSimklDatabase',
            is_folder=False,
            description=g.get_language_string(30390),
            menu_item=g.create_icon_dict("simkl_rebuild", g.ICONS_PATH),
        )
        g.close_directory(g.CONTENT_MENU)

    @staticmethod
    def test_windows():
        g.add_directory_item(
            g.get_language_string(30462),
            action='testPlayingNext',
            is_folder=False,
            description=g.get_language_string(30391),
            menu_item=g.create_icon_dict("test", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30463),
            action='testStillWatching',
            is_folder=False,
            description=g.get_language_string(30392),
            menu_item=g.create_icon_dict("test", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30818),
            action='testSkipSegment',
            is_folder=False,
            description=g.get_language_string(30819),
            menu_item=g.create_icon_dict("test", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30823),
            action='testSkipOutro',
            is_folder=False,
            description=g.get_language_string(30824),
            menu_item=g.create_icon_dict("test", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30613),
            action='testGetSourcesWindow',
            is_folder=False,
            description=g.get_language_string(30614),
            menu_item=g.create_icon_dict("test", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30464),
            action='testResolverWindow',
            is_folder=False,
            description=g.get_language_string(30393),
            menu_item=g.create_icon_dict("test", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30465),
            action='testSourceSelectWindow',
            is_folder=False,
            description=g.get_language_string(30394),
            menu_item=g.create_icon_dict("test", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30466),
            action='testManualCacheWindow',
            is_folder=False,
            description=g.get_language_string(30460),
            menu_item=g.create_icon_dict("test", g.ICONS_PATH),
        )
        g.add_directory_item(
            g.get_language_string(30626),
            action='testDownloadManagerWindow',
            is_folder=False,
            description=g.get_language_string(30625),
            menu_item=g.create_icon_dict("test", g.ICONS_PATH),
        )
        g.close_directory(g.CONTENT_MENU)
