from resources.lib.modules.globals import g

# from resources.lib.common import maintenance


def do_version_change():
    old_version = g.get_setting("prism.version")
    if old_version == g.CLEAN_VERSION:
        return

    g.log("Clearing cache on Prism version change", "info")
    g.clear_cache(silent=True)

    from resources.lib.modules.release_migration import flag_migration_wipe_on_version_cross
    from resources.lib.modules.simkl_rebuild_migration import (
        flag_simkl_rebuild_on_version_cross,
        maybe_run_pending_simkl_rebuild,
    )

    flag_migration_wipe_on_version_cross(old_version, g.CLEAN_VERSION)
    flag_simkl_rebuild_on_version_cross(old_version, g.CLEAN_VERSION)

    g.set_setting("prism.version", g.CLEAN_VERSION)
    maybe_run_pending_simkl_rebuild()

    # Reuselanguageinvoker update.  This should be last to execute as it can do a profile reload.

    # Disable the restoration of reuselanguageinvoker addon.xml based on settings value on upgrade.
    # It can still be toggled in settings, although initially it will be the release default value.
    # This is due to the fact that we still don't recommend having this enabled due to Kodi hard crashes.
    # maintenance.toggle_reuselanguageinvoker(
    #     True if g.get_setting("reuselanguageinvoker") == "Enabled" else False)
    g.set_setting(
        "reuselanguageinvoker.status", "Disabled"
    )  # This ensures setting is reflected as disabled on version change
