"""
Per-catalog filter and sort profiles (movie / tv / anime).
"""

import json
import time

from resources.lib.common.source_utils import tag_at_sort_index
from resources.lib.modules.globals import g

# #region agent log
_DEBUG_LOG_PATH = r"C:\Users\jenki\Desktop\Prism\debug-a54591.log"


def _agent_debug_log(location, message, data=None, hypothesis_id=None, run_id="pre-fix"):
    try:
        payload = {
            "sessionId": "a54591",
            "timestamp": int(time.time() * 1000),
            "location": location,
            "message": message,
            "data": data or {},
            "hypothesisId": hypothesis_id,
            "runId": run_id,
        }
        with open(_DEBUG_LOG_PATH, "a", encoding="utf-8") as _f:
            _f.write(json.dumps(payload) + "\n")
    except Exception:
        pass


def _sortmethod_snapshot(catalog):
    return {
        f"L{level}": g.get_int_setting(
            sortmethod_key(catalog, level), DEFAULT_SORTMETHOD.get(level, 0)
        )
        for level in range(1, 7)
    }


# #endregion

CATALOGS = ("movie", "tv", "anime")
LAST_CATALOG_KEY = "general.filter.lastcatalog"
MIGRATION_FLAG_KEY = "general.catalogprofiles.migrated"
SORT_V2_MIGRATION_FLAG_KEY = "general.sortconfig.v2.migrated"
SORT_V2_CORRUPTION_REPAIR_KEY = "general.sortconfig.v2.modern_corruption.repaired"

DEFAULT_FILTERS = "3D,AV1"

# Anime filter presets (enabled tags are excluded from scrape results).
ANIME_BASE_FILTERS = frozenset({"3D", "AV1"})
ANIME_FILTER_PRESETS = {
    "sub": ANIME_BASE_FILTERS | {"DUB"},
    "dub": ANIME_BASE_FILTERS | {"SUB", "MULTI-SUB", "HC"},
}

# sortmethod indices: 2=Source Type, 1=Resolution, 10=Audio, 11=Subtitles, 4=Size, 0=None
DEFAULT_SORTMETHOD = {1: 2, 2: 1, 3: 10, 4: 11, 5: 4, 6: 0, 7: 0, 8: 0}
# sourcetypesort option indices: 5=Direct, 1=Cloud, 2=Adaptive, 0=Other
DEFAULT_SOURCETYPESORT = {1: 5, 2: 1, 3: 2, 4: 0, 5: 0}
DEFAULT_HDRSORT = {1: 2, 2: 0}
DEFAULT_HDRCODECSORT = {1: 2, 2: 0, 3: 0}
DEFAULT_VIDEOCODECSORT = {1: 0, 2: 0, 3: 0, 4: 0}
DEFAULT_AUDIOCODECSORT = {1: 0, 2: 0, 3: 0, 4: 0}
DEFAULT_MISCSORT = {1: 0, 2: 0, 3: 0, 4: 0}
DEFAULT_AUDIOCHANNELSSORT = {1: 1, 2: 2, 3: 3}
DEFAULT_DEBRIDSORT = {1: 1, 2: 0, 3: 0, 4: 0}
# audiosort: 2=Dual-Audio, 1=Multi-Audio, 0=None
DEFAULT_AUDIOSORT = {1: 2, 2: 1, 3: 0, 4: 0}
# subtitlesort: 1=Multi-Sub
DEFAULT_SUBTITLESORT = {1: 1}

# Legacy global keys in settings.xml (pre per-catalog profiles) — unchanged factory values.
_LEGACY_FACTORY_SORTMETHOD = {1: 2, 2: 1, 3: 4, 4: 0, 5: 0, 6: 0, 7: 0, 8: 0}
_LEGACY_FACTORY_SOURCETYPESORT = {1: 1, 2: 0, 3: 0, 4: 0, 5: 0}


def _legacy_global_sort_profile_is_factory_default() -> bool:
    """True when the user never customized legacy sort settings (fresh install)."""
    for level, expected in _LEGACY_FACTORY_SORTMETHOD.items():
        if g.get_int_setting(f"general.sortmethod.{level}", expected) != expected:
            return False
    for level, expected in _LEGACY_FACTORY_SOURCETYPESORT.items():
        if g.get_int_setting(f"general.sourcetypesort.{level}", expected) != expected:
            return False
    return True


def _migrate_legacy_sort_to_catalog(catalog: str) -> None:
    """Copy legacy global sort keys into one catalog profile."""
    for level in range(1, 9):
        for reverse in (False, True):
            legacy = f"general.sortmethod.{level}" + (".reverse" if reverse else "")
            new_key = sortmethod_key(catalog, level, reverse=reverse)
            if g.get_setting(new_key) is not None:
                continue
            value = g.get_setting(legacy)
            if value is not None:
                g.set_setting(new_key, value)
            elif not reverse:
                g.set_setting(new_key, DEFAULT_SORTMETHOD[level])
            else:
                g.set_setting(new_key, False)

    for level, default in DEFAULT_SOURCETYPESORT.items():
        new_key = sub_sort_key(catalog, "sourcetypesort", level)
        if g.get_setting(new_key) is None:
            legacy = g.get_setting(f"general.sourcetypesort.{level}")
            g.set_setting(new_key, legacy if legacy is not None else default)

    for level, default in DEFAULT_HDRSORT.items():
        new_key = sub_sort_key(catalog, "hdrsort", level)
        if g.get_setting(new_key) is None:
            legacy = g.get_setting(f"general.hdrsort.{level}")
            g.set_setting(new_key, legacy if legacy is not None else default)

    for level, default in DEFAULT_DEBRIDSORT.items():
        new_key = sub_sort_key(catalog, "debridsort", level)
        if g.get_setting(new_key) is None:
            legacy = g.get_setting(f"general.debridsort.{level}")
            g.set_setting(new_key, legacy if legacy is not None else default)

    for level, default in DEFAULT_AUDIOSORT.items():
        new_key = sub_sort_key(catalog, "audiosort", level)
        if g.get_setting(new_key) is None:
            legacy = g.get_setting(f"general.audiosort.{level}")
            g.set_setting(new_key, legacy if legacy is not None else default)

    for level, default in DEFAULT_SUBTITLESORT.items():
        new_key = sub_sort_key(catalog, "subtitlesort", level)
        if g.get_setting(new_key) is None:
            legacy = g.get_setting(f"general.subtitlesort.{level}")
            g.set_setting(new_key, legacy if legacy is not None else default)

    for category, defaults in _TAG_SORT_DEFAULTS.items():
        for sub_level, default in defaults.items():
            key = sub_sort_key(catalog, category, sub_level)
            if g.get_setting(key) is None:
                g.set_setting(key, default)


OLD_TO_NEW_SORTMETHOD = {
    0: 0,
    1: 1,
    2: 2,
    3: 3,
    4: 4,
    5: 0,
    6: 5,
    7: 6,
    8: 9,
    9: 10,
    10: 11,
}

OLD_HDR_PRIORITY = {0: None, 1: "DV", 2: "HDR"}

# Anime sort presets — indices match sort_select.SORT_METHODS / SORT_OPTIONS.
_ANIME_SORT_PRESET_SHARED = {
    "sortmethod": {1: 2, 2: 1, 3: 10, 4: 0, 5: 0, 6: 0, 7: 0, 8: 0},
    "sourcetypesort": {1: 5, 2: 1, 3: 2, 4: 0, 5: 0},
    "hdrcodecsort": DEFAULT_HDRCODECSORT,
    "debridsort": DEFAULT_DEBRIDSORT,
}

ANIME_SORT_PRESETS = {
    "sub": {
        **_ANIME_SORT_PRESET_SHARED,
        "sortmethod": {1: 2, 2: 1, 3: 10, 4: 11, 5: 4, 6: 0, 7: 0, 8: 0},
        "audiosort": {1: 2, 2: 1, 3: 3, 4: 0},
        "subtitlesort": {1: 1},
    },
    "dub": {
        **_ANIME_SORT_PRESET_SHARED,
        "sortmethod": {1: 2, 2: 1, 3: 10, 4: 4, 5: 0, 6: 0, 7: 0, 8: 0},
        "audiosort": {1: 2, 2: 1, 3: 4, 4: 0},
        "subtitlesort": {1: 0},
    },
}

_TAG_SORT_DEFAULTS = {
    "videocodecsort": DEFAULT_VIDEOCODECSORT,
    "hdrcodecsort": DEFAULT_HDRCODECSORT,
    "audiocodecsort": DEFAULT_AUDIOCODECSORT,
    "miscsort": DEFAULT_MISCSORT,
    "audiochannelssort": DEFAULT_AUDIOCHANNELSSORT,
}

_SORT_PRESET_CATEGORIES = (
    ("sourcetypesort", DEFAULT_SOURCETYPESORT),
    ("videocodecsort", DEFAULT_VIDEOCODECSORT),
    ("hdrcodecsort", DEFAULT_HDRCODECSORT),
    ("audiocodecsort", DEFAULT_AUDIOCODECSORT),
    ("miscsort", DEFAULT_MISCSORT),
    ("audiochannelssort", DEFAULT_AUDIOCHANNELSSORT),
    ("debridsort", DEFAULT_DEBRIDSORT),
    ("audiosort", DEFAULT_AUDIOSORT),
    ("subtitlesort", DEFAULT_SUBTITLESORT),
)

_SUB_SORT_DEFAULTS = (
    ("sourcetypesort", DEFAULT_SOURCETYPESORT),
    ("videocodecsort", DEFAULT_VIDEOCODECSORT),
    ("hdrcodecsort", DEFAULT_HDRCODECSORT),
    ("audiocodecsort", DEFAULT_AUDIOCODECSORT),
    ("miscsort", DEFAULT_MISCSORT),
    ("audiochannelssort", DEFAULT_AUDIOCHANNELSSORT),
    ("debridsort", DEFAULT_DEBRIDSORT),
    ("audiosort", DEFAULT_AUDIOSORT),
    ("subtitlesort", DEFAULT_SUBTITLESORT),
)

# Anime playback locale presets (Kodi English names).
ANIME_PLAYBACK_PRESETS = {
    "sub": {
        "use_kodi": False,
        "audio": "Japanese",
        "subtitle": "English",
        "subtitlekeyword": "dialog",
    },
    "dub": {
        "use_kodi": False,
        "audio": "English",
        "subtitle": "none",
        "subtitlekeyword": "signs_songs",
    },
}


def normalize_catalog(catalog):
    if catalog in CATALOGS:
        return catalog
    return "movie"


def filters_key(catalog):
    return f"general.filters.{normalize_catalog(catalog)}"


def sortmethod_key(catalog, level, reverse=False):
    suffix = ".reverse" if reverse else ""
    return f"general.sortmethod.{normalize_catalog(catalog)}.{level}{suffix}"


def sub_sort_key(catalog, category, level):
    return f"general.{category}.{normalize_catalog(catalog)}.{level}"


def _tag_sort_index(struct_key, tag_name):
    for index in range(32):
        if tag_at_sort_index(struct_key, index) == tag_name:
            return index
    return 0


def resolve_catalog_from_item_information(item_information):
    """Resolve movie / tv / anime for filter-sort profiles.

    Priority: action_args (widget-safe) → sync row → info → anime ids → show DB → mediatype.
    """
    if not item_information:
        return "movie"

    action_args = item_information.get("action_args") or {}
    info = item_information.get("info") or {}

    for candidate in (
        action_args.get("catalog"),
        item_information.get("catalog"),
        info.get("catalog"),
    ):
        if candidate in CATALOGS:
            return candidate

    if info.get("mal_id") or info.get("mal_show_id"):
        return "anime"

    mediatype = info.get("mediatype") or action_args.get("mediatype")
    if mediatype == "movie":
        return "movie"

    if mediatype in ("tvshow", "season", "episode"):
        show_id = info.get("simkl_show_id")
        if show_id is None and mediatype == "tvshow":
            show_id = action_args.get("simkl_id") or info.get("simkl_id")
        if show_id is None and mediatype == "season":
            show_id = action_args.get("simkl_id")
        if show_id is None and mediatype == "episode":
            from resources.lib.simkl.ids import show_id_for_episode_action

            show_id = show_id_for_episode_action(action_args)
        if show_id is not None:
            from resources.lib.database.session import get_sync_database

            catalog = get_sync_database().show_catalog(int(show_id))
            if catalog in CATALOGS:
                return catalog

    return "tv"


def get_last_catalog():
    return normalize_catalog(g.get_setting(LAST_CATALOG_KEY, "movie"))


def set_last_catalog(catalog):
    g.set_setting(LAST_CATALOG_KEY, normalize_catalog(catalog))


def _map_legacy_sortmethod_index(old_val: int) -> int:
    """Map pre-v2 sortmethod indices (0–9) to current SORT_METHODS indices."""
    if old_val >= 10:
        return old_val
    return OLD_TO_NEW_SORTMETHOD.get(old_val, old_val)


def _repair_sort_v2_modern_corruption() -> None:
    """Restore Audio row when sort v2 treated modern indices 10/11 as legacy."""
    for catalog in CATALOGS:
        l3 = g.get_int_setting(sortmethod_key(catalog, 3), DEFAULT_SORTMETHOD.get(3, 0))
        l4 = g.get_int_setting(sortmethod_key(catalog, 4), DEFAULT_SORTMETHOD.get(4, 0))
        if l3 != 11 or l4 != 11:
            continue
        g.set_setting(sortmethod_key(catalog, 3), DEFAULT_SORTMETHOD[3])
        for level, value in DEFAULT_AUDIOSORT.items():
            g.set_setting(sub_sort_key(catalog, "audiosort", level), value)
        # #region agent log
        _agent_debug_log(
            "catalog_profiles._repair_sort_v2_modern_corruption",
            "repaired duplicate subtitles rows",
            {"catalog": catalog, "sortmethods": _sortmethod_snapshot(catalog)},
            hypothesis_id="fix",
            run_id="post-fix",
        )
        # #endregion


def _migrate_sort_v2():
    for catalog in CATALOGS:
        old_sortmethods = {
            level: g.get_int_setting(sortmethod_key(catalog, level), DEFAULT_SORTMETHOD.get(level, 0))
            for level in range(1, 9)
        }

        for level, old_method in old_sortmethods.items():
            if old_method == 6:
                hevc_idx = _tag_sort_index("videocodec", "HEVC")
                if g.get_int_setting(sub_sort_key(catalog, "videocodecsort", 1), 0) == 0:
                    g.set_setting(sub_sort_key(catalog, "videocodecsort", 1), hevc_idx)
            elif old_method == 7:
                for sub_level in range(1, 4):
                    old_hdr_idx = g.get_int_setting(
                        sub_sort_key(catalog, "hdrsort", sub_level),
                        DEFAULT_HDRSORT.get(sub_level, 0),
                    )
                    tag = OLD_HDR_PRIORITY.get(old_hdr_idx)
                    if tag:
                        g.set_setting(
                            sub_sort_key(catalog, "hdrcodecsort", sub_level),
                            _tag_sort_index("hdrcodec", tag),
                        )
            elif old_method == 8:
                for sub_level, default in DEFAULT_AUDIOCHANNELSSORT.items():
                    g.set_setting(sub_sort_key(catalog, "audiochannelssort", sub_level), default)

        for level in range(1, 9):
            old_val = old_sortmethods[level]
            mapped = _map_legacy_sortmethod_index(old_val)
            # #region agent log
            if level in (3, 4, 5):
                _agent_debug_log(
                    "catalog_profiles._migrate_sort_v2",
                    "sortmethod remap",
                    {
                        "catalog": catalog,
                        "level": level,
                        "old_val": old_val,
                        "mapped": mapped,
                    },
                    hypothesis_id="C",
                    run_id="post-fix",
                )
            # #endregion
            g.set_setting(sortmethod_key(catalog, level), mapped)

        for category, defaults in _TAG_SORT_DEFAULTS.items():
            for sub_level, default in defaults.items():
                key = sub_sort_key(catalog, category, sub_level)
                if g.get_setting(key) is None:
                    g.set_setting(key, default)


def ensure_migrated():
    if not g.get_bool_setting(MIGRATION_FLAG_KEY):
        legacy_filters = g.get_setting("general.filters")
        if legacy_filters is None:
            legacy_filters = DEFAULT_FILTERS

        for catalog in CATALOGS:
            key = filters_key(catalog)
            if g.get_setting(key) is None:
                g.set_setting(key, legacy_filters)

        use_modern_sort_defaults = _legacy_global_sort_profile_is_factory_default()
        # #region agent log
        _agent_debug_log(
            "catalog_profiles.ensure_migrated",
            "catalog profile migration start",
            {
                "use_modern_sort_defaults": use_modern_sort_defaults,
                "legacy_global_L3": g.get_int_setting("general.sortmethod.3", -1),
                "legacy_global_L4": g.get_int_setting("general.sortmethod.4", -1),
            },
            hypothesis_id="A",
        )
        # #endregion
        for catalog in CATALOGS:
            if use_modern_sort_defaults:
                reset_sort_profile(catalog)
                # #region agent log
                _agent_debug_log(
                    "catalog_profiles.ensure_migrated",
                    "after reset_sort_profile",
                    {"catalog": catalog, "sortmethods": _sortmethod_snapshot(catalog)},
                    hypothesis_id="B",
                )
                # #endregion
            else:
                _migrate_legacy_sort_to_catalog(catalog)

        g.set_setting(MIGRATION_FLAG_KEY, True)

    if not g.get_bool_setting(SORT_V2_MIGRATION_FLAG_KEY):
        # #region agent log
        _agent_debug_log(
            "catalog_profiles.ensure_migrated",
            "before _migrate_sort_v2",
            {"movie": _sortmethod_snapshot("movie")},
            hypothesis_id="B",
        )
        # #endregion
        _migrate_sort_v2()
        # #region agent log
        _agent_debug_log(
            "catalog_profiles.ensure_migrated",
            "after _migrate_sort_v2",
            {"movie": _sortmethod_snapshot("movie")},
            hypothesis_id="D",
        )
        # #endregion
        g.set_setting(SORT_V2_MIGRATION_FLAG_KEY, True)

    if not g.get_bool_setting(SORT_V2_CORRUPTION_REPAIR_KEY):
        _repair_sort_v2_modern_corruption()
        g.set_setting(SORT_V2_CORRUPTION_REPAIR_KEY, True)


def get_filters(catalog):
    ensure_migrated()
    filter_string = g.get_setting(filters_key(catalog), DEFAULT_FILTERS)
    return set() if not filter_string else set(filter_string.split(","))


def save_filters(catalog, filter_set):
    g.set_setting(filters_key(catalog), ",".join(sorted(filter_set)) if filter_set else "")


def load_sort_options(catalog):
    ensure_migrated()
    catalog = normalize_catalog(catalog)
    options = {
        sortmethod_key(catalog, idx): g.get_int_setting(sortmethod_key(catalog, idx), DEFAULT_SORTMETHOD[idx])
        for idx in range(1, 9)
    }
    options.update(
        {
            sortmethod_key(catalog, idx, reverse=True): g.get_bool_setting(
                sortmethod_key(catalog, idx, reverse=True), False
            )
            for idx in range(1, 9)
        }
    )
    for category, defaults in _SUB_SORT_DEFAULTS:
        for level, default in defaults.items():
            options[sub_sort_key(catalog, category, level)] = g.get_int_setting(
                sub_sort_key(catalog, category, level), default
            )
    return options


def reset_filters(catalog):
    save_filters(catalog, set(DEFAULT_FILTERS.split(",")))


def apply_anime_filter_preset(preset: str) -> bool:
    """Apply sub/dub filter preset for the anime catalog profile."""
    key = str(preset or "").strip().lower()
    filter_set = ANIME_FILTER_PRESETS.get(key)
    if filter_set is None:
        return False
    save_filters("anime", set(filter_set))
    return True


def apply_anime_sort_preset(preset: str) -> bool:
    """Apply sub/dub sort preset for the anime catalog profile."""
    key = str(preset or "").strip().lower()
    profile = ANIME_SORT_PRESETS.get(key)
    if profile is None:
        return False

    ensure_migrated()
    catalog = "anime"
    sort_levels = profile.get("sortmethod") or {}
    for level in range(1, 9):
        g.set_setting(sortmethod_key(catalog, level), sort_levels.get(level, 0))
        g.set_setting(sortmethod_key(catalog, level, reverse=True), False)

    for category, defaults in _SORT_PRESET_CATEGORIES:
        preset_levels = profile.get(category) or {}
        for level, default in defaults.items():
            g.set_setting(
                sub_sort_key(catalog, category, level),
                preset_levels.get(level, default),
            )
    return True


def apply_anime_playback_preset(preset: str) -> bool:
    """Apply sub/dub playback locale preset for the anime catalog profile."""
    key = str(preset or "").strip().lower()
    profile = ANIME_PLAYBACK_PRESETS.get(key)
    if profile is None:
        return False

    from resources.lib.modules.locale_playback import (
        set_catalog_audio,
        set_catalog_subtitle,
        set_use_kodi_defaults,
    )
    from resources.lib.modules.playback_streams import (
        set_custom_subtitle_keyword,
        set_subtitle_keyword_mode,
    )

    set_use_kodi_defaults("anime", bool(profile.get("use_kodi", False)))
    set_catalog_audio("anime", profile["audio"])
    set_catalog_subtitle("anime", profile["subtitle"])
    set_subtitle_keyword_mode(str(profile.get("subtitlekeyword", "off")))
    return True


def apply_anime_preset(preset: str) -> bool:
    """Apply full anime sub/dub preset: filters, sort, and playback locale.

    Prefer the scoped helpers when changing a single settings screen.
    """
    key = str(preset or "").strip().lower()
    if key not in ANIME_FILTER_PRESETS:
        return False
    apply_anime_filter_preset(key)
    apply_anime_sort_preset(key)
    apply_anime_playback_preset(key)
    return True


def reset_sort_profile(catalog):
    catalog = normalize_catalog(catalog)
    for level, value in DEFAULT_SORTMETHOD.items():
        g.set_setting(sortmethod_key(catalog, level), value)
        g.set_setting(sortmethod_key(catalog, level, reverse=True), False)
    for category, defaults in _SUB_SORT_DEFAULTS:
        for level, value in defaults.items():
            g.set_setting(sub_sort_key(catalog, category, level), value)
