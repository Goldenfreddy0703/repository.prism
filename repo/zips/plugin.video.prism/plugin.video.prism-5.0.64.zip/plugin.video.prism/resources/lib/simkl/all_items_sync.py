"""Watchlist foundation sync via ``GET /sync/all-items`` (one call per phase).

``extended=full,full_anime_seasons`` loads per-episode watch-state arrays plus anime
TVDB season mapping — not episode catalog metadata (titles/thumbs/plot come from
``GET /tv/episodes/{id}`` via episode warm). Show overview/fanart/genres/ratings come
from Simkl detail endpoints (see ``enrich.enrich_page_for_paint``).
"""
from __future__ import annotations

import time
from typing import TYPE_CHECKING

from resources.lib.modules.globals import g
from resources.lib.simkl.library import _unwrap_sync_items, simkl_entry_to_sync_dict
from resources.lib.simkl.statuses import MOVIE_STATUS_OPTIONS, SHOW_STATUS_OPTIONS

if TYPE_CHECKING:
    from resources.lib.database.simkl_sync.activities import SimklSyncDatabase

# Comma-separated extended flags: episode arrays + runtime + anime TVDB season mapping.
ALL_ITEMS_EXTENDED = "full,full_anime_seasons"
EPISODE_PRUNE_AFTER_SYNC = True

_MOVIE_STATUSES = tuple(status for status, _ in MOVIE_STATUS_OPTIONS)
_SHOW_STATUSES = tuple(status for status, _ in SHOW_STATUS_OPTIONS)


def _completed_or_dropped_changed(remote_activities, local_watermark: str) -> bool:
    """True when completed/dropped lists moved since our last all-items watermark."""
    from resources.lib.database.simkl_sync.database import SimklSyncDatabase

    for section in ("movies", "tv_shows", "anime"):
        section_data = remote_activities.get(section) or {}
        for status in ("completed", "dropped"):
            ts = section_data.get(status)
            if ts and SimklSyncDatabase.requires_update(ts, local_watermark):
                return True
    return False


def _completed_or_dropped_changed(remote_activities, local_watermark: str) -> bool:
    """True when completed/dropped lists moved since our last all-items watermark."""
    from resources.lib.database.simkl_sync.database import SimklSyncDatabase

    for section in ("movies", "tv_shows", "anime"):
        section_data = remote_activities.get(section) or {}
        for status in ("completed", "dropped"):
            ts = section_data.get(status)
            if ts and SimklSyncDatabase.requires_update(ts, local_watermark):
                return True
    return False


def _episode_activity_changed(remote_activities, local_watermark: str) -> bool:
    """True when episode-level Simkl activity moved since our last all-items watermark."""
    from resources.lib.database.simkl_sync.database import SimklSyncDatabase

    for section in ("movies", "tv_shows", "anime"):
        section_data = remote_activities.get(section) or {}
        for field in ("watched", "episodes", "playback"):
            ts = section_data.get(field)
            if ts and SimklSyncDatabase.requires_update(ts, local_watermark):
                return True
    return False


def _playback_activity_changed(db: "SimklSyncDatabase", remote_activities) -> bool:
    movies_at = (remote_activities.get("movies") or {}).get("playback")
    if movies_at and db.requires_update(movies_at, db.activities["movies_bookmarked"]):
        return True
    for section in ("tv_shows", "anime"):
        playback_at = (remote_activities.get(section) or {}).get("playback")
        if playback_at and db.requires_update(playback_at, db.activities["episodes_bookmarked"]):
            return True
    return False


def build_foundation_params(*, date_from: str, include_all_episodes: bool = True) -> dict:
    """Phase 1 / heavy baseline — full episode arrays for first sync."""
    params = {
        "date_from": date_from,
        "extended": ALL_ITEMS_EXTENDED,
        "next_watch_info": "yes",
        "episode_watched_at": "yes",
        "episode_tvdb_id": "yes",
    }
    if include_all_episodes:
        params["include_all_episodes"] = "yes"
    return params


def build_lean_delta_params(*, date_from: str) -> dict:
    """Phase 2 lean delta — membership and counters only."""
    return {"date_from": date_from, "next_watch_info": "yes"}


def build_episode_delta_params(*, date_from: str, include_all_episodes: bool = False) -> dict:
    """Phase 2 episode delta — per-episode watch arrays when activity requires them."""
    params = {
        "date_from": date_from,
        "extended": ALL_ITEMS_EXTENDED,
        "next_watch_info": "yes",
        "episode_watched_at": "yes",
        "episode_tvdb_id": "yes",
    }
    if include_all_episodes:
        params["include_all_episodes"] = "yes"
    return params


def build_all_items_params(*, date_from: str, include_all_episodes: bool = False) -> dict:
    """Legacy alias — foundation-style params."""
    return build_foundation_params(date_from=date_from, include_all_episodes=include_all_episodes)


def fetch_all_items(
    api,
    *,
    date_from: str,
    first_sync: bool = False,
    episode_detail: bool = False,
    include_all_episodes: bool = False,
):
    if first_sync:
        params = build_foundation_params(date_from=date_from, include_all_episodes=include_all_episodes or True)
    elif episode_detail:
        params = build_episode_delta_params(date_from=date_from, include_all_episodes=include_all_episodes)
    else:
        params = build_lean_delta_params(date_from=date_from)
    url = "/sync/all-items/"
    query = dict(params)
    if hasattr(api, "_cdn_query"):
        query.update(api._cdn_query())
    response = api.get(url, **query)
    if response is None:
        return None
    try:
        return response.json()
    except ValueError:
        return None


def ingest_payload(
    db: "SimklSyncDatabase",
    payload,
    *,
    is_delta: bool = False,
    lean_delta: bool = False,
) -> None:
    """Unified all-items ingest — foundation and delta share one code path."""
    if not payload:
        return

    if not is_delta:
        if _unwrap_sync_items(payload, "movies"):
            db.set_sync_progress(15, g.get_language_string(31001))
        if _unwrap_sync_items(payload, "shows"):
            db.set_sync_progress(35, g.get_language_string(31002))
        if _unwrap_sync_items(payload, "anime"):
            db.set_sync_progress(50, g.get_language_string(31003))

    db._process_all_items_payload(payload)

    if EPISODE_PRUNE_AFTER_SYNC:
        db.prune_library_episodes()
    db.set_sync_progress(60, g.get_language_string(31010))
    if _payload_has_items(payload):
        _seed_display_meta_from_payload(db, payload)
    _upsert_catalog_items_from_payload(payload)
    if lean_delta:
        _materialize_library_after_delta(db)
    else:
        _audit_catalog_external_ids(db, payload)
        _materialize_library_after_sync(db)
    rebuild_library_cache_from_db(db)
    phase = "delta" if is_delta else "foundation"
    g.log(f"Simkl all-items ingest complete ({phase})", "info")


def _payload_has_items(payload) -> bool:
    for media_key in ("movies", "shows", "anime"):
        if _unwrap_sync_items(payload, media_key):
            return True
    return False


def _reapply_episode_watch_state_after_warm(db: "SimklSyncDatabase", payload) -> None:
    """Episode catalog warm upserts rows with watched=0; restore Simkl watch flags afterward."""
    if not payload:
        return
    for catalog, media_key in (("tv", "shows"), ("anime", "anime")):
        entries = _unwrap_sync_items(payload, media_key)
        if not entries:
            continue
        shows = []
        for entry in entries:
            normalized = simkl_entry_to_sync_dict(entry, catalog)
            if normalized:
                shows.append(normalized)
        if shows:
            db.reapply_episode_watch_state_from_entries(entries, shows)


def rebuild_library_cache_from_db(db: "SimklSyncDatabase" | None = None) -> None:
    from resources.lib.database.session import get_sync_database
    from resources.lib.simkl.library_cache import _save_cached_refs

    db = db or get_sync_database()
    for status in _MOVIE_STATUSES:
        refs = db.get_movies_by_simkl_status(status)
        for ref in refs:
            ref["catalog"] = "movie"
        _save_cached_refs("movie", status, refs)
    for catalog in ("tv", "anime"):
        for status in _SHOW_STATUSES:
            refs = db.get_shows_by_simkl_status(status, catalog=catalog)
            for ref in refs:
                ref["catalog"] = catalog
            _save_cached_refs(catalog, status, refs)


def _upsert_catalog_items_from_payload(payload) -> None:
    from resources.lib.discover.catalog_store import upsert_sync_items

    items: list[dict] = []
    for entry in _unwrap_sync_items(payload, "movies"):
        normalized = simkl_entry_to_sync_dict(entry, "movie")
        if normalized:
            items.append(normalized)
    for catalog, media_key in (("tv", "shows"), ("anime", "anime")):
        for entry in _unwrap_sync_items(payload, media_key):
            normalized = simkl_entry_to_sync_dict(entry, catalog)
            if normalized:
                items.append(normalized)
    if items:
        upsert_sync_items(items)


def _materialize_library_priority_buckets() -> None:
    """Page-1 library status stamps for fast menu open (priority buckets)."""
    from resources.lib.meta.menu_paint_profile import MenuPaintProfile
    from resources.lib.meta.page_materialize import materialize_refs_from_sync_db
    from resources.lib.simkl.library_cache import _load_refs_from_sync_db
    from resources.lib.simkl.library_list_sync import _statuses_for_catalog
    from resources.lib.simkl.menu_helpers import library_list_page

    profile = MenuPaintProfile.LIBRARY.value
    warm_statuses = frozenset({"watching", "plantowatch", "completed", "dropped"})
    for catalog in ("movie", "tv", "anime"):
        for status in _statuses_for_catalog(catalog):
            if status not in warm_statuses:
                continue
            refs = _load_refs_from_sync_db(catalog, status)
            if not refs:
                continue
            page_refs, _ = library_list_page(refs)
            if page_refs:
                materialize_refs_from_sync_db(catalog, page_refs, profile=profile)


def _materialize_library_after_sync(db: "SimklSyncDatabase") -> None:
    _materialize_library_priority_buckets()


def _materialize_library_after_delta(db: "SimklSyncDatabase") -> None:
    _materialize_library_priority_buckets()


def _audit_catalog_external_ids(db: "SimklSyncDatabase", payload) -> None:
    """Log library titles missing external IDs Simkl provided in all-items payloads."""
    missing: list[str] = []
    checks = (
        ("movie", "movies", ("tmdb", "imdb")),
        ("tv", "shows", ("tmdb", "tvdb", "imdb")),
        ("anime", "anime", ("tmdb", "tvdb", "mal")),
    )
    for catalog, media_key, id_keys in checks:
        for entry in _unwrap_sync_items(payload, media_key):
            normalized = simkl_entry_to_sync_dict(entry, catalog)
            if not normalized:
                continue
            simkl_id = normalized.get("simkl_id")
            ids = normalized.get("ids") or {}
            gaps = [key for key in id_keys if ids.get(key) and not normalized.get(f"{key}_id")]
            if gaps and simkl_id is not None:
                missing.append(f"{catalog}:{simkl_id}({','.join(gaps)})")
    if missing:
        sample = ", ".join(missing[:12])
        suffix = "..." if len(missing) > 12 else ""
        g.log(
            f"Simkl catalog ID audit: {len(missing)} title(s) missing mapped ID columns — {sample}{suffix}",
            "debug",
        )


def _seed_display_meta_from_payload(db: "SimklSyncDatabase", payload) -> None:
    """Seed title/poster from lean sync rows; plot/fanart filled on menu open."""
    from resources.lib.meta.display_store import get_display_meta_store
    from resources.lib.meta.storage import slim_art_dict, slim_info_dict
    from resources.lib.modules.metadataHandler import MetadataHandler

    store = get_display_meta_store()
    rows_by_type: dict[str, list[dict]] = {"movie": [], "tvshow": []}
    for entry in _unwrap_sync_items(payload, "movies"):
        normalized = simkl_entry_to_sync_dict(entry, "movie")
        if not normalized:
            continue
        simkl_obj = normalized.get("simkl_object") or {}
        info = slim_info_dict(MetadataHandler.simkl_info(normalized) or {}, simkl=True)
        art = slim_art_dict(MetadataHandler.art(simkl_obj) or {}, "movie")
        if info or art:
            rows_by_type["movie"].append({"simkl_id": normalized["simkl_id"], "info": info, "art": art, "cast": []})
    for catalog, media_key in (("tv", "shows"), ("anime", "anime")):
        art_type = "anime" if catalog == "anime" else "tvshow"
        for entry in _unwrap_sync_items(payload, media_key):
            normalized = simkl_entry_to_sync_dict(entry, catalog)
            if not normalized:
                continue
            simkl_obj = normalized.get("simkl_object") or {}
            info = slim_info_dict(MetadataHandler.simkl_info(normalized) or {}, simkl=True)
            art = slim_art_dict(MetadataHandler.art(simkl_obj) or {}, art_type)
            if info or art:
                rows_by_type["tvshow"].append({"simkl_id": normalized["simkl_id"], "info": info, "art": art, "cast": []})
    for media_type, rows in rows_by_type.items():
        if rows:
            store.set_many_rows(media_type, rows)


def _finalize_episode_sync_state(
    db: "SimklSyncDatabase",
    payload,
    *,
    force: bool = False,
    blocking_warm: bool = False,
) -> None:
    """Restore episode watch flags after sync. Episode menu warm is a separate action."""
    del force, blocking_warm
    _reapply_episode_watch_state_after_warm(db, payload)


_LIBRARY_WATCH_STATUSES = frozenset({"watching", "plantowatch", "completed", "hold", "dropped"})


def _find_show_entry(payload, media_key: str, show_id: int) -> dict | None:
    from resources.lib.database.simkl_sync.database import SimklSyncDatabase

    for entry in _unwrap_sync_items(payload, media_key):
        if SimklSyncDatabase._entry_show_simkl_id(entry) == show_id:
            return entry
    return None


def build_repair_watch_params(*, include_all_episodes: bool = False) -> dict:
    """Full watch-state params for one-show repair (no date_from — deltas omit episode arrays)."""
    params = {
        "extended": ALL_ITEMS_EXTENDED,
        "next_watch_info": "yes",
        "episode_watched_at": "yes",
        "episode_tvdb_id": "yes",
    }
    if include_all_episodes:
        params["include_all_episodes"] = "yes"
    return params


def _library_entry_from_sync_watched(item: dict, catalog: str) -> dict | None:
    """Convert POST /sync/watched response row into all-items-style library entry."""
    if not isinstance(item, dict) or not item.get("result") or item.get("result") == "not_found":
        return None
    show_id = item.get("simkl")
    if show_id is None:
        return None
    entry: dict = {
        "status": item.get("list"),
        "watched_episodes_count": item.get("episodes_watched"),
        "total_episodes_count": item.get("episodes_total"),
        "last_watched_at": item.get("last_watched_at"),
        "seasons": [],
    }
    blob = {"ids": {"simkl": int(show_id)}}
    if catalog == "anime":
        entry["anime"] = blob
    else:
        entry["show"] = blob
    for season in item.get("seasons") or []:
        if not isinstance(season, dict) or season.get("number") is None:
            continue
        episodes = []
        for episode in season.get("episodes") or []:
            if not isinstance(episode, dict):
                continue
            ep_num = episode.get("number") if episode.get("number") is not None else episode.get("episode")
            if ep_num is None:
                continue
            ep_row = {"number": int(ep_num)}
            ep_ids = episode.get("ids")
            if isinstance(ep_ids, dict) and ep_ids:
                ep_row["ids"] = dict(ep_ids)
            if episode.get("watched") in (True, 1, "true", "True"):
                ep_row["watched"] = True
            elif episode.get("watched") in (False, 0, "false", "False"):
                ep_row["watched"] = False
            if episode.get("last_watched_at"):
                ep_row["watched_at"] = episode["last_watched_at"]
            episodes.append(ep_row)
        entry["seasons"].append({"number": int(season["number"]), "episodes": episodes})
    return entry


def fetch_show_watch_entry_from_sync_watched(api, show_id: int, catalog: str) -> dict | None:
    """Per-show watch repair via POST /sync/watched?extended=episodes,specials."""
    response = api.post_json(
        "/sync/watched",
        [{"ids": {"simkl": int(show_id)}}],
        extended="episodes,specials",
    )
    if not isinstance(response, list) or not response:
        return None
    item = response[0]
    if not isinstance(item, dict):
        return None
    return _library_entry_from_sync_watched(item, catalog)


def _episode_watch_cooldown_active(show_id: int) -> bool:
    cooldown_raw = g.get_runtime_setting(f"episode_watch_refresh_cooldown_{show_id}")
    if not cooldown_raw:
        return False
    try:
        return (time.time() - float(cooldown_raw)) < 120
    except (TypeError, ValueError):
        return False


def _local_watched_episode_keys(db: "SimklSyncDatabase", show_id: int) -> set[tuple[int, int]]:
    catalog = db.show_catalog(int(show_id)) or "tv"
    from resources.lib.database.simkl_sync.serial_sync import serial_tables

    ep_table = serial_tables("anime" if catalog == "anime" else "tv").episode
    rows = db.fetchall(
        f"""
        SELECT season, number
        FROM {ep_table}
        WHERE simkl_show_id=? AND season != 0 AND COALESCE(watched, 0) > 0
        """,
        (show_id,),
    )
    return {(int(row["season"]), int(row["number"])) for row in rows or []}


def _remote_watched_episode_keys(
    db: "SimklSyncDatabase",
    entry: dict,
    *,
    show_id: int | None = None,
    catalog: str | None = None,
) -> set[tuple[int, int]]:
    keys: set[tuple[int, int]] = set()
    if show_id is None:
        show_id = db._entry_show_simkl_id(entry)
    if catalog is None and show_id is not None:
        catalog = db.show_catalog(int(show_id)) or "tv"
    anime_raw_cache: dict[int, list[dict]] = {}
    anime_slug_cache: dict[int, str | None] = {}
    for season in entry.get("seasons") or []:
        if not isinstance(season, dict):
            continue
        season_num = season.get("number") if season.get("number") is not None else season.get("season")
        if season_num is None:
            continue
        for episode in season.get("episodes") or []:
            if not isinstance(episode, dict):
                continue
            ep_num = episode.get("number") if episode.get("number") is not None else episode.get("episode")
            if ep_num is None:
                continue
            if not db._episode_marked_watched(episode, entry):
                continue
            resolved_season = int(season_num)
            resolved_episode = int(ep_num)
            if show_id is not None:
                resolved_season, resolved_episode = db._resolve_episode_watch_coords_for_db(
                    int(show_id),
                    episode,
                    resolved_season,
                    resolved_episode,
                    catalog or "tv",
                    anime_raw_cache,
                    anime_slug_cache,
                )
            keys.add((resolved_season, resolved_episode))
    return keys


def _show_watch_state_matches(
    db: "SimklSyncDatabase",
    *,
    show_id: int,
    entry: dict,
    local_status: str,
    resolved_status: str,
) -> bool:
    """True when local DB watch state already matches Simkl (safe to use cached menus)."""
    remote_watched = int(entry.get("watched_episodes_count") or 0)
    local_watched = len(_local_watched_episode_keys(db, show_id))
    remote_status = str(entry.get("status") or "").strip().lower()

    if resolved_status and remote_status and resolved_status != remote_status:
        return False
    if local_status and remote_status and local_status != remote_status:
        return False
    if local_watched != remote_watched:
        return False

    if db._entry_has_explicit_episode_watch_fields(entry):
        return _local_watched_episode_keys(db, show_id) == _remote_watched_episode_keys(
            db, entry, show_id=show_id
        )

    catalog = db.show_catalog(int(show_id)) or "tv"
    row = db.fetchone(
        "SELECT watched_episodes FROM shows WHERE simkl_id=? AND catalog=?",
        (show_id, catalog),
    )
    show_watched = int((row or {}).get("watched_episodes") or 0)
    if show_watched > 0 and remote_watched > 0 and show_watched != remote_watched:
        return False
    return True


def _reconcile_show_watch_entry(
    db: "SimklSyncDatabase",
    show_id: int,
    entry: dict,
    catalog: str,
    status: str,
) -> int:
    """Apply Simkl watch entry to the local DB; return watched episode row count."""
    media_key = "anime" if catalog == "anime" else "shows"
    watch_entry = entry
    stub_entry = entry
    if status in _LIBRARY_WATCH_STATUSES:
        params = build_repair_watch_params(
            include_all_episodes=status in ("completed", "dropped"),
        )
        payload = db.simkl_api.get_all_items(media_key, status=status, **params)
        richer = _find_show_entry(payload, media_key, show_id)
        if richer and db._entry_has_full_episode_watch_detail(richer):
            stub_entry = richer
            # Keep POST /sync/watched when it already has per-episode watched booleans.
            # all-items "watching" rows are often partial and lack explicit watched flags,
            # which previously triggered a reset that cleared every local episode flag.
            if not db._entry_has_explicit_episode_watch_fields(watch_entry):
                if db._entry_has_explicit_episode_watch_fields(richer) or (
                    not db._entry_has_per_episode_watch_rows(watch_entry)
                    and db._entry_has_per_episode_watch_rows(richer)
                ):
                    watch_entry = richer

    normalized = simkl_entry_to_sync_dict(watch_entry, catalog)
    if not normalized:
        return 0

    shows = [normalized]
    has_episode_detail = db._entry_has_full_episode_watch_detail(stub_entry)
    has_watched_flags = db._entry_has_per_episode_watch_rows(watch_entry)
    simkl_watched_count = int(watch_entry.get("watched_episodes_count") or 0)
    from resources.lib.database.simkl_sync.serial_sync import serial_tables

    st = serial_tables(catalog)
    local_episode_rows = int(
        (db.fetchone(
            f"SELECT COUNT(*) AS c FROM {st.episode} WHERE simkl_show_id=? AND season != 0",
            (show_id,),
        ) or {}).get("c")
        or 0
    )
    if has_episode_detail and local_episode_rows == 0:
        db.apply_sync_episode_stubs_from_entries([stub_entry], shows, catalog, selective=True)

    db._apply_entry_watch_state([watch_entry], shows)
    local_watched_after = len(_local_watched_episode_keys(db, show_id))
    if has_watched_flags and simkl_watched_count > 0 and local_watched_after < simkl_watched_count:
        db.apply_sync_episode_stubs_from_entries([stub_entry], shows, catalog, selective=True)
        db._apply_entry_watch_state([watch_entry], shows)
        local_watched_after = len(_local_watched_episode_keys(db, show_id))
    if simkl_watched_count > 0 and local_watched_after < simkl_watched_count:
        db.apply_watched_episodes_from_entries([watch_entry], shows)
        local_watched_after = len(_local_watched_episode_keys(db, show_id))
    if simkl_watched_count > 0 and local_watched_after < simkl_watched_count and stub_entry is not watch_entry:
        db.apply_watched_episodes_from_entries([stub_entry], shows)
        local_watched_after = len(_local_watched_episode_keys(db, show_id))
    if simkl_watched_count > 0 and local_watched_after < simkl_watched_count:
        progress_applied = db.apply_watched_progress_from_entry(watch_entry)
        local_watched_after = max(local_watched_after, progress_applied)
    db.apply_show_watch_counters([watch_entry])
    if status == "completed":
        db.apply_completed_show_watch_flags([watch_entry])
    if catalog == "anime":
        db.prune_orphan_anime_seasons(show_id)
    db._refresh_show_and_season_statistics(show_id)
    return local_watched_after


def ensure_show_episode_watch_aligned_for_paint(
    db: "SimklSyncDatabase",
    simkl_show_id: int,
    *,
    catalog: str | None = None,
) -> bool:
    """
    Block season drilldown paint when per-episode watched flags disagree with Simkl.

    Show-level totals can match while individual episode rows are stale (wrong season checkmarks).
    """
    if not db.simkl_api.is_authenticated():
        return False

    show_id = int(simkl_show_id)
    if _episode_watch_cooldown_active(show_id):
        return False

    if catalog is None:
        catalog = db.show_catalog(show_id) or "tv"
    row = db.fetchone(
        "SELECT simkl_status, watched_episodes FROM shows WHERE simkl_id=? AND catalog=?",
        (show_id, catalog),
    )
    if not row:
        return False

    local_status = str(row.get("simkl_status") or "").strip().lower()
    show_watched = int(row.get("watched_episodes") or 0)
    local_keys = _local_watched_episode_keys(db, show_id)
    if show_watched <= 0 and not local_keys:
        return False

    entry = fetch_show_watch_entry_from_sync_watched(db.simkl_api, show_id, catalog)
    if not entry:
        return False

    remote_watched = int(entry.get("watched_episodes_count") or 0)
    remote_status = str(entry.get("status") or "").strip().lower()
    resolved_status = local_status or (
        remote_status if remote_status in _LIBRARY_WATCH_STATUSES else "watching"
    )

    needs_reconcile = False
    if remote_watched > 0 and len(local_keys) != remote_watched:
        needs_reconcile = True
    elif show_watched > 0 and len(local_keys) != show_watched:
        needs_reconcile = True
    elif db._entry_has_full_episode_watch_detail(entry) and (remote_watched > 0 or local_keys):
        remote_keys = _remote_watched_episode_keys(db, entry, show_id=show_id, catalog=catalog)
        if local_keys != remote_keys:
            needs_reconcile = True
    elif db._entry_has_explicit_episode_watch_fields(entry):
        remote_keys = _remote_watched_episode_keys(db, entry, show_id=show_id, catalog=catalog)
        if local_keys != remote_keys:
            needs_reconcile = True

    if not needs_reconcile:
        return False

    local_watched_after = _reconcile_show_watch_entry(
        db, show_id, entry, catalog, resolved_status
    )
    try:
        from resources.lib.meta.paint_cache import clear_session_page_paint_for_show

        clear_session_page_paint_for_show(show_id)
    except Exception:
        pass
    db._refresh_show_and_season_statistics(show_id)
    g.log(
        f"Menu perf: drilldown pre-paint watch reconcile show={show_id} -> "
        f"{local_watched_after} watched episode(s)",
        "info",
    )
    return True


def refresh_show_episode_watch_state(db: "SimklSyncDatabase", simkl_show_id: int, *, force: bool = False) -> bool:
    """Validate per-show watch state against Simkl; reconcile only when local data drifted."""
    if not db.simkl_api.is_authenticated():
        return False

    show_id = int(simkl_show_id)
    catalog = db.show_catalog(show_id) or "tv"
    row = db.fetchone(
        "SELECT simkl_status, watched_episodes, episode_count FROM shows WHERE simkl_id=? AND catalog=?",
        (show_id, catalog),
    )
    if not row:
        return False

    local_status = str(row.get("simkl_status") or "").strip().lower()

    if _episode_watch_cooldown_active(show_id):
        if not force:
            return len(_local_watched_episode_keys(db, show_id)) > 0
        g.log(
            f"Simkl watch verify: skip forced reconcile for show {show_id} (recent local edit)",
            "debug",
        )
        return len(_local_watched_episode_keys(db, show_id)) > 0

    entry = fetch_show_watch_entry_from_sync_watched(db.simkl_api, show_id, catalog)
    if not entry:
        return False

    remote_status = str(entry.get("status") or "").strip().lower()
    remote_watched = int(entry.get("watched_episodes_count") or 0)
    if remote_status not in _LIBRARY_WATCH_STATUSES and remote_watched <= 0:
        return False

    # List bucket membership is owned by library_list_sync (/sync/all-items).
    # /sync/watched is only used here for episode-level watch flags.
    resolved_status = local_status
    if not resolved_status and remote_status in _LIBRARY_WATCH_STATUSES:
        resolved_status = remote_status

    if not force and _show_watch_state_matches(
        db,
        show_id=show_id,
        entry=entry,
        local_status=local_status,
        resolved_status=resolved_status,
    ):
        g.log(
            f"Simkl watch verify: show {show_id} matches remote ({remote_watched} watched) — cache ok",
            "debug",
        )
        return remote_watched > 0 or len(_local_watched_episode_keys(db, show_id)) > 0

    local_watched_after = _reconcile_show_watch_entry(db, show_id, entry, catalog, resolved_status)
    try:
        from resources.lib.meta.paint_cache import clear_session_page_paint_for_show

        clear_session_page_paint_for_show(show_id)
    except Exception:
        pass
    g.log(
        f"Simkl watch reconcile: show {show_id} ({resolved_status or 'watching'}) -> "
        f"{local_watched_after} watched episode(s)",
        "info",
    )
    return local_watched_after > 0


def sync_simkl_library(db: "SimklSyncDatabase", remote_activities, *, force: bool = False) -> None:
    first_sync = str(db.activities["all_activities"]) == db.base_date
    date_from = db.base_date if first_sync else str(db.activities["all_activities"])
    local_watermark = str(db.activities["all_activities"])
    include_all_episodes = first_sync or _completed_or_dropped_changed(remote_activities, local_watermark)
    episode_detail = first_sync or include_all_episodes or _episode_activity_changed(
        remote_activities, local_watermark
    ) or _playback_activity_changed(db, remote_activities)
    lean_delta = not first_sync and not episode_detail

    phase_label = "foundation" if first_sync else ("episode_delta" if episode_detail else "lean_delta")
    extended_label = ALL_ITEMS_EXTENDED if episode_detail or first_sync else "none"
    g.log(
        f"Simkl all-items: extended={extended_label}, "
        f"include_all_episodes={'yes' if include_all_episodes else 'no'}, "
        f"phase={phase_label}",
        "debug",
    )

    db.set_sync_progress(5, g.get_language_string(31000))
    payload = fetch_all_items(
        db.simkl_api,
        date_from=date_from,
        first_sync=first_sync,
        episode_detail=episode_detail,
        include_all_episodes=include_all_episodes,
    )
    if payload:
        ingest_payload(db, payload, is_delta=not first_sync, lean_delta=lean_delta)

    if db._removed_from_list_changed(remote_activities):
        db._reconcile_removed_items()
        rebuild_library_cache_from_db(db)

    from resources.lib.simkl.library_cache import record_library_sync_watermark

    record_library_sync_watermark(db)

    _finalize_episode_sync_state(
        db,
        payload,
        force=force,
        blocking_warm=True,
    )
    db.set_sync_progress(100, g.get_language_string(31013))
