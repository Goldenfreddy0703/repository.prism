from __future__ import annotations

import copy
import datetime
import hashlib
import json
import os
import re
import sys
from collections.abc import Mapping
from functools import total_ordering
from urllib import parse

import xbmc
import xbmcvfs

youtube_url = "plugin://plugin.video.youtube/play/?video_id={}"

DIGIT_REGEX = re.compile(r"\d")
SORT_TOKENS = [
    "a ",
    "an ",
    "das ",
    "de ",
    "der ",
    "die ",
    "een ",
    "el ",
    "het ",
    "i ",
    "il ",
    "l'",
    "la ",
    "le ",
    "les ",
    "o ",
    "the ",
]
SORT_TOKEN_REGEX = re.compile(r"|".join(fr"^{i}" for i in SORT_TOKENS), re.IGNORECASE)

SHORT_MONTH_LOOKUP = {
    "Jan": 1,
    "Feb": 2,
    "Mar": 3,
    "Apr": 4,
    "May": 5,
    "Jun": 6,
    "Jul": 7,
    "Aug": 8,
    "Sep": 9,
    "Oct": 10,
    "Nov": 11,
    "Dec": 12,
}


def copy2clip(txt):
    """
    Takes a text string and attempts to copy it to the clipboard of the device
    :param txt: Text to send to clipboard
    :type txt: str
    :return: None
    :rtype: None
    """
    import subprocess

    platform = sys.platform
    if platform == "win32":
        try:
            cmd = f"echo {txt.strip()}|clip"
            return subprocess.check_call(cmd, shell=True)
        except Exception as e:
            log(f"Failure to copy to clipboard, \n{e}", "error")
    elif platform.startswith("linux") or platform == "darwin":
        try:
            from subprocess import Popen, PIPE

            cmd = "pbcopy" if platform == "darwin" else ["xsel", "-pi"]
            kwargs = {"stdin": PIPE, "text": True}
            p = Popen(cmd, **kwargs)
            p.communicate(input=str(txt))
        except Exception as e:
            log(f"Failure to copy to clipboard, \n{e}", "error")


def parse_datetime(string_date, date_only=True):
    """
    Attempts to pass over provided string and return a date or datetime object
    :param string_date: String to parse
    :type string_date: str
    :param date_only: Whether to return a date only object or not
    :type date_only: bool
    :return: datetime.datetime object
    :rtype: datetime.datetime
    """
    if not string_date:
        return None

    # Don't use datetime.datetime.strptime()
    # Workaround for python bug caching of strptime in datetime module.
    # Don't just try to detect TypeError because it breaks meta handler lambda calls occasionally, particularly
    # with unix style threading.
    try:
        res = datetime.datetime.fromisoformat(string_date.rstrip("Z"))
    except ValueError:
        if "/" in string_date:
            parts = string_date.strip().split("/")
            if len(parts) == 3:
                try:
                    a, b, c = (int(p) for p in parts)
                    if c >= 1000:
                        month, day, year = a, b, c
                        if month > 12:
                            day, month, year = a, b, c
                        res = datetime.datetime(year=year, month=month, day=day)
                        return res.date() if date_only else res
                except ValueError:
                    pass
        try:
            day, month, year = string_date.split(" ", 2)
            month = SHORT_MONTH_LOOKUP[month]
            res = datetime.datetime(year=int(year), month=month, day=int(day))
        except (ValueError, KeyError) as exc:
            raise ValueError(f"Unable to parse date: {string_date}") from exc

    return res.date() if date_only else res


def shortened_debrid(debrid):
    """
    Returns a display like version of provided backend label
    :param debrid: backend debrid label
    :type debrid: str
    :return: shorthand display style debrid label
    :rtype: str
    """
    debrid = debrid.lower()
    if debrid == "premiumize":
        return "PM"
    if debrid == "real_debrid":
        return "RD"
    if debrid == "all_debrid":  # sourcery skip: assign-if-exp
        return "AD"
    if debrid == "torbox":
        return "TB"
    if debrid == "offcloud":
        return "OC"
    else:
        return ""


def source_size_display(size):
    """
    Converts source size (MB) to a display string (MB below 1 GiB, else GB).
    :param size: Size of source in MB
    :type size: int|float|str
    :return: Formatted string for size
    :rtype: str
    """
    if size == "Variable":
        return size

    try:
        size_mb = float(size)
    except (TypeError, ValueError):
        return "0.00 GB"

    if size_mb <= 0:
        return "0.00 GB"

    if size_mb < 1024:
        if size_mb >= 100:
            return f"{size_mb:.0f} MB"
        return f"{size_mb:.2f} MB"

    return f"{size_mb / 1024:.2f} GB"


def bytes_size_display(size):
    """
    Converts source size (bytes) to best fitting *binary* prefix display string
    :param size: Size of source in bytes
    :type size: int
    :return: Formatted string for size with best fitting *binary* prefix suffix
    :rtype: str
    """
    size = float(size)
    suffix = "B"
    if size > 1024:
        size /= 1024
        suffix = "KiB"
    if size > 1024:
        size = size / 1024
        suffix = "MiB"
    if size > 1024:
        size = size / 1024
        suffix = "GiB"
    if size > 1024:
        size = size / 1024
        suffix = "TiB"
    return f"{size:{'.0f' if size.is_integer() else '.2f'}} {suffix}"


def paginate_list(list_items, page, limit):
    """
    Paginate items and returns requested page
    :param list_items: list of items to paginate
    :type list_items: list
    :param page: requested page
    :type page: int
    :param limit: items per page
    :type limit: int
    :return: items on page
    :rtype: list
    """
    if page - 1 > float(len(list_items)) / limit:
        return []
    return list_items[(page - 1) * limit : page * limit]


def italic_string(text):
    """
    Ease of use method to return a italic like ready string for display in Kodi
    :param text: Text to display in italics
    :type text: str
    :return: Formatted string
    :rtype: str
    """

    return f"[I]{text}[/I]"


def compare_version_numbers(current, new, include_same=False):
    """
    Compares provided version numbers and returns True if new version is higher
    If include_same = True will also return true if the new and old versions match
    :param current: Version number to check against
    :type current: str
    :param new: Remote/New version number to check against
    :type new: str
    :param include_same: Whether to additionally return True if versions match
    :type new: bool
    :return: True if new version number is higher than the current, else False
    :rtype: bool
    """
    if include_same and new == current:
        return True

    current = current.split(".")
    new = new.split(".")
    for step, i in enumerate(new):
        if len(current) - 1 < step:
            return True
        if int(current[step]) > int(i):
            return False
        if int(current[step]) < int(i):
            return True
    return False


def _episode_item_has_info(item: dict | list | None) -> bool:
    if not isinstance(item, dict):
        return False
    info = item.get("info")
    return isinstance(info, dict) and info.get("simkl_id") is not None


def _catalog_from_action_args(action_args) -> str:
    if isinstance(action_args, dict) and action_args.get("catalog") in ("anime", "tv", "movie"):
        return str(action_args["catalog"])
    return "tv"


def _serial_profile_scope(db, catalog: str):
    from resources.lib.database.simkl_sync.serial_sync import serial_profile_scope

    profile = "anime" if catalog == "anime" else "tv"
    return serial_profile_scope(db, profile)


def _show_sync_row(db, show_id: int, catalog: str):
    with _serial_profile_scope(db, catalog):
        st = db._st()
        return db.fetchone(
            f"SELECT info, imdb_id, tmdb_id, tvdb_id FROM {st.show} WHERE simkl_id = ?",
            (int(show_id),),
        )


def _resolve_episode_show_id(db, action_args, episode_id):
    from resources.lib.simkl.ids import show_id_for_episode_action

    show_id = show_id_for_episode_action(action_args)
    if show_id is not None or episode_id is None:
        return show_id

    catalog = _catalog_from_action_args(action_args)
    with _serial_profile_scope(db, catalog):
        st = db._st()
        row = db.fetchone(
            f"SELECT simkl_show_id FROM {st.episode} WHERE simkl_id = ?",
            (int(episode_id),),
        )
    if row and row.get("simkl_show_id") is not None:
        return int(row["simkl_show_id"])

    return _show_id_from_video_playlist()


def _show_id_from_video_playlist():
    """Best-effort show id from other binge playlist items."""
    try:
        import json
        from urllib import parse

        import xbmc

        from resources.lib.simkl.ids import show_id_from_playlist_action_args

        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        for idx in range(playlist.size()):
            path = playlist[idx].getPath() or ""
            if "action_args=" not in path:
                continue
            query = path.split("?", 1)[-1]
            for key, value in parse.parse_qsl(query):
                if key != "action_args":
                    continue
                try:
                    action_args = json.loads(parse.unquote(value))
                except (TypeError, ValueError):
                    continue
                show_id = show_id_from_playlist_action_args(action_args)
                if show_id is not None:
                    return int(show_id)
    except Exception:
        pass
    return None


def _find_episode_row_by_coords(db, show_id, season_num, episode_num, catalog: str = "tv"):
    with _serial_profile_scope(db, catalog):
        st = db._st()
        row = db.fetchone(
            f"""
            SELECT simkl_id
            FROM {st.episode}
            WHERE simkl_show_id = ? AND season = ? AND number = ?
            LIMIT 1
            """,
            (int(show_id), int(season_num), int(episode_num)),
        )
        if row and row.get("simkl_id") is not None:
            episode_row = db.get_episode(int(row["simkl_id"]), int(show_id))
            if _episode_item_has_info(episode_row):
                return episode_row

        list_kwargs = {
            "season": int(season_num),
            "hide_unaired": False,
            "hide_watched": False,
            "skip_update": True,
            "skip_watch_refresh": True,
        }
        if catalog == "anime":
            rows = db.get_anime_episode_list(int(show_id), **list_kwargs)
        else:
            rows = db.get_episode_list(int(show_id), **list_kwargs)
        for candidate in rows:
            info = candidate.get("info") or {}
            ep_num = info.get("episode")
            if ep_num is None:
                ep_num = info.get("number")
            if int(info.get("season", -1)) == int(season_num) and int(ep_num or -1) == int(episode_num):
                return candidate
    return None


def _synthesize_external_episode_item(db, show_id, season_num, episode_num, action_args):
    from resources.lib.simkl.field_map import ensure_episode_title, inherit_show_fields
    from resources.lib.simkl.ids import attach_tv_context, season_key, synthetic_episode_id

    show_row = db.get_show(int(show_id))
    if not isinstance(show_row, dict):
        show_row = {}
    show_info = show_row.get("info") if isinstance(show_row.get("info"), dict) else {}
    catalog = (
        action_args.get("catalog")
        or show_info.get("catalog")
        or show_row.get("catalog")
        or "tv"
    )

    ep_simkl_id = synthetic_episode_id(int(show_id), int(season_num), int(episode_num))
    ep_info = {
        "simkl_id": ep_simkl_id,
        "mediatype": "episode",
        "catalog": catalog,
        "season": int(season_num),
        "episode": int(episode_num),
        "number": int(episode_num),
        "simkl_show_id": int(show_id),
        "simkl_season_id": season_key(int(show_id), int(season_num)),
        "external_play": True,
    }
    inherit_show_fields(ep_info, show_info)
    ensure_episode_title(ep_info)
    attach_tv_context(
        ep_info,
        int(show_id),
        season_num=int(season_num),
        season_row_id=ep_info["simkl_season_id"],
    )

    return {
        "simkl_id": ep_simkl_id,
        "simkl_show_id": int(show_id),
        "info": ep_info,
        "art": show_row.get("art") or {},
        "cast": show_row.get("cast") or [],
        "catalog": catalog,
        "is_airing": show_row.get("is_airing") or show_info.get("is_airing"),
        "season_count": show_row.get("season_count") or show_info.get("season_count"),
        "episode_count": show_row.get("episode_count") or show_info.get("episode_count"),
    }


def _load_episode_item_information(db, action_args, episode_id, show_id):
    if not episode_id or not show_id:
        return {}

    catalog = _catalog_from_action_args(action_args)
    from resources.lib.simkl.ids import resolve_episode_db_simkl_id

    requested_episode_id = int(episode_id)
    db_episode_id = resolve_episode_db_simkl_id(
        db, requested_episode_id, int(show_id), catalog
    )
    if db_episode_id is None:
        db_episode_id = requested_episode_id

    list_kwargs = {
        "simkl_id": db_episode_id,
        "hide_unaired": False,
        "hide_watched": False,
        "skip_update": True,
        "skip_watch_refresh": True,
    }
    if catalog == "anime":
        episode_row = db.get_episode(db_episode_id, int(show_id))
        if isinstance(episode_row, list):
            episode_row = {}
        if _episode_item_has_info(episode_row):
            return episode_row
        rows = db.get_anime_episode_list(int(show_id), **list_kwargs)
    else:
        episode_row = db.get_episode(db_episode_id, show_id)
        if isinstance(episode_row, list):
            episode_row = {}
        if _episode_item_has_info(episode_row):
            return episode_row
        rows = db.get_episode_list(int(show_id), **list_kwargs)
    if rows:
        return rows[0]

    return {}


def get_item_information(action_args):
    """
    Ease of use tool to retrieve items meta from SimklSyncDatabase based on action arguments
    :param action_args: action arguments received in call to Prism
    :type action_args: dict
    :return: Metadata for item
    :rtype: dict
    """
    if action_args is None:
        return None

    if isinstance(action_args, dict) and action_args.get("mediatype") is None:
        nested_args = action_args.get("action_args")
        if isinstance(nested_args, dict):
            action_args = nested_args

    from resources.lib.simkl.ids import (
        episode_id_from_args,
        normalize_action_args,
        season_num_from_args,
        show_id_from_args,
    )

    action_args = normalize_action_args(action_args)
    item_information = {"action_args": action_args}
    mediatype = action_args.get("mediatype")

    from resources.lib.simkl.field_map import attach_show_scraper_context, finalize_playback_info, inherit_show_fields
    from resources.lib.modules import catalog_profiles

    def _finalize(item: dict) -> dict:
        info = item.get("info")
        if isinstance(info, dict):
            finalize_playback_info(info)
            info["catalog"] = catalog_profiles.resolve_catalog_from_item_information(
                {**item, "action_args": action_args}
            )
        return item

    if mediatype == "tvshow":
        from resources.lib.database.session import get_sync_database

        item_information.update(get_sync_database().get_show(action_args["simkl_id"]))
        return _finalize(item_information)

    if mediatype == "season":
        from resources.lib.database.session import get_sync_database

        show_id = show_id_from_args(action_args)
        season_num = season_num_from_args(action_args)
        db = get_sync_database()
        catalog = _catalog_from_action_args(action_args)
        if catalog == "anime":
            rows = db.get_anime_season_list(
                show_id, season=season_num, hide_unaired=False, hide_watched=False
            )
        else:
            rows = db.get_season_list(show_id, season=season_num, hide_unaired=False, hide_watched=False)
        item_information.update(rows[0] if rows else {})
        return _finalize(item_information)

    if mediatype == "episode":
        from resources.lib.database.session import get_sync_database

        db = get_sync_database()

        if action_args.get("external_play") and action_args.get("simkl_show_id") is not None:
            show_id = int(action_args["simkl_show_id"])
            season_num = action_args.get("season")
            episode_num = action_args.get("episode")
            if season_num is not None and episode_num is not None:
                item_information.update(
                    _synthesize_external_episode_item(
                        db, show_id, int(season_num), int(episode_num), action_args
                    )
                )
                tmdb_show_id = action_args.get("tmdb_id")
                try:
                    tmdb_show_id = int(tmdb_show_id) if tmdb_show_id is not None else None
                except (TypeError, ValueError):
                    tmdb_show_id = None
                if tmdb_show_id is None:
                    show_row = db.get_show(show_id)
                    if isinstance(show_row, dict):
                        try:
                            tmdb_show_id = int(show_row.get("tmdb_id")) if show_row.get("tmdb_id") is not None else None
                        except (TypeError, ValueError):
                            tmdb_show_id = None
                        if tmdb_show_id is None and isinstance(show_row.get("info"), dict):
                            try:
                                tmdb_show_id = int(show_row["info"].get("tmdb_id")) if show_row["info"].get("tmdb_id") is not None else None
                            except (TypeError, ValueError):
                                tmdb_show_id = None
                if tmdb_show_id is not None:
                    from resources.lib.modules.tmdb_helper import (
                        apply_tmdb_episode_meta,
                        fetch_tmdb_episode,
                    )

                    apply_tmdb_episode_meta(
                        item_information,
                        fetch_tmdb_episode(
                            tmdb_show_id,
                            int(season_num),
                            int(episode_num),
                            hide_unaired=False,
                        ),
                    )
                info = item_information.get("info")
                if isinstance(info, dict):
                    show_row = db.get_show(show_id)
                    show_info = (show_row or {}).get("info") if isinstance(show_row, dict) else None
                    if isinstance(show_info, dict):
                        for col in ("imdb_id", "tmdb_id", "tvdb_id"):
                            if isinstance(show_row, dict) and show_row.get(col) and not show_info.get(col):
                                show_info[col] = show_row[col]
                        attach_show_scraper_context(item_information, show_info)
                return _finalize(item_information)

        episode_id = episode_id_from_args(action_args)
        show_id = _resolve_episode_show_id(db, action_args, episode_id)
        if show_id is None and action_args.get("simkl_show_id") is not None:
            show_id = int(action_args["simkl_show_id"])
        episode_row = _load_episode_item_information(db, action_args, episode_id, show_id)
        if not _episode_item_has_info(episode_row) and show_id and episode_id:
            from resources.lib.simkl.ids import resolve_episode_db_simkl_id

            catalog_hint = _catalog_from_action_args(action_args)
            db_key = resolve_episode_db_simkl_id(
                db, int(episode_id), int(show_id), catalog_hint
            )
            if db_key and int(db_key) != int(episode_id):
                episode_row = _load_episode_item_information(
                    db, action_args, db_key, show_id
                )
            if not _episode_item_has_info(episode_row) and db_key:
                direct = db.get_episode(int(db_key), int(show_id))
                if isinstance(direct, dict) and _episode_item_has_info(direct):
                    episode_row = direct
        if episode_row:
            item_information.update(episode_row)
        info = item_information.get("info")
        if isinstance(info, dict) and show_id:
            catalog = _catalog_from_action_args(action_args)
            show_row = _show_sync_row(db, int(show_id), catalog)
            show_info = (show_row or {}).get("info")
            if isinstance(show_info, dict):
                for col in ("imdb_id", "tmdb_id", "tvdb_id"):
                    if show_row.get(col) and not show_info.get(col):
                        show_info[col] = show_row[col]
                attach_show_scraper_context(item_information, show_info)
        return _finalize(item_information)

    if mediatype == "movie":
        from resources.lib.database.session import get_sync_database

        item_information.update(get_sync_database().get_movie(action_args["simkl_id"]))
        return _finalize(item_information)


def deconstruct_action_args(action_args):
    """
    Attempts to create a dictionary from the calls action args
    :param action_args: potential url quoted, stringed dict
    :type action_args:  str
    :return: unquoted and loaded dictionary or str if not json
    :rtype: dict, str
    """
    action_args = parse.unquote(action_args)
    try:
        return json.loads(action_args)
    except (ValueError, json.JSONDecodeError):
        return action_args


def construct_action_args(action_args):
    """
    Takes a json capable response, dumps and urlquotes it ready for URL appending
    :param action_args: Valid JSON
    :type action_args: list, dict
    :return: Url quoted response
    :rtype: str
    """
    if isinstance(action_args, dict):
        info = action_args.get("info")
        if action_args.get("simkl_object") or (isinstance(info, dict) and info.get("mediatype")):
            from resources.lib.simkl.ids import build_action_args

            action_args = build_action_args(action_args)
        elif action_args.get("simkl_id") and action_args.get("mediatype"):
            from resources.lib.simkl.ids import normalize_action_args

            action_args = normalize_action_args(action_args) or action_args
    return parse.quote(json.dumps(action_args, sort_keys=True))


def extend_array(array1, array2):
    """
    Safe combining of two lists
    :param array1: List to combine
    :type array1: list
    :param array2: List to combine
    :type array2: list
    :return: Combined lists
    :rtype: list
    """
    result = []
    if array1 and isinstance(array1, list):
        result.extend(array1)
    if array2 and isinstance(array2, list):
        result.extend(array2)
    return result


def smart_merge_dictionary(dictionary, merge_dict, keep_original=False, extend_array=True):
    """Method for merging large multi typed dictionaries, it has support for handling arrays.

    :param dictionary:Original dictionary to merge the second on into.
    :type dictionary:dict
    :param merge_dict:Dictionary that is used to merge into the original one.
    :type merge_dict:dict
    :param keep_original:Boolean that indicates if there are duplicated values to keep the original one.
    :type keep_original:bool
    :param extend_array:Boolean that indicates if we need to extend existing arrays with the enw values..
    :type extend_array:bool
    :return:Merged dictionary
    :rtype:dict
    """
    if not isinstance(dictionary, dict) or not isinstance(merge_dict, dict):
        return dictionary
    for new_key, new_value in merge_dict.items():
        original_value = copy.deepcopy(dictionary.get(new_key))
        if isinstance(new_value, (dict, Mapping)):
            if original_value is None:
                original_value = {}
            new_value = smart_merge_dictionary(original_value, new_value, keep_original, extend_array)
        else:
            if original_value and keep_original:
                continue
            if extend_array and isinstance(original_value, (list, set)) and isinstance(new_value, (list, set)):
                if isinstance(original_value, set):
                    original_value.update(x for x in new_value if x not in original_value)
                    try:
                        new_value = set(sorted(original_value))
                    except TypeError:  # Sorting of complex array doesn't work.
                        new_value = original_value
                else:
                    original_value.extend(x for x in new_value if x not in original_value)
                    try:
                        new_value = sorted(original_value)
                    except TypeError:  # Sorting of complex array doesn't work.
                        new_value = original_value
        if new_value or new_value == 0 or isinstance(new_value, bool):
            # We want to skip empty lists / dicts / sets
            dictionary[new_key] = new_value
    return dictionary


def freeze_object(o):
    """
    Takes in a iterable object, freezes all dicts, tuples lists/sets
    :param o: Object to free
    :type o: dict/set/list/tuple
    :return: Hashable object
    :rtype: tuple, frozenset
    """
    if isinstance(o, dict):
        return frozenset({k: freeze_object(v) for k, v in o.items()}.items())

    if isinstance(o, (set, tuple, list)):
        return tuple(freeze_object(v) for v in o)

    return o


def serialize_sets(obj):
    return sorted([str(i) for i in obj]) if isinstance(obj, set) else obj


def md5_hash(value):
    """
    Returns MD5 hash of given value
    :param value: object to hash
    :type value: object
    :return: Hexdigest of hash
    :rtype: str
    """
    if isinstance(value, (tuple, dict, list, set)):
        value = json.dumps(value, sort_keys=True, default=serialize_sets)
    return hashlib.md5(str(value).encode("utf-8")).hexdigest()


# Re-added for provider backwards compatibility support
def log(msg, level):
    """
    Legacy compat method to log message
    :param msg: Message to write to log
    :type msg: str
    :param level: Log level
    :type level: str
    :return: None
    :rtype: None
    """
    from resources.lib.modules.globals import g

    g.log(msg, level)


def run_threaded(target_func, *args, **kwargs):
    """
    Ease of use method to spawn a new thread and run without joining
    :param target_func: function to run
    :type target_func: Any
    :param args: tuple of arguments to pass through to function
    :type args: (int) - > None
    :param kwargs: dictionary of kwargs to pass to function
    :type kwargs: (int) - > None
    :return: The started thread
    :rtype: threading.Thread
    """
    from threading import Thread

    from resources.lib.common.thread_pool import prism_plugin_no_threads

    if prism_plugin_no_threads():
        target_func(*args, **kwargs)
        return None

    thread = Thread(target=target_func, args=args, kwargs=kwargs, daemon=True)
    thread.start()
    return thread


def wait_container_ready(
    step_ms: int,
    timeout_ms: int,
    *path_markers: str,
    require_item_count: bool = False,
) -> bool:
    """Wait until the active Kodi folder matches *path_markers* and is ready to scroll."""
    import xbmc
    import xbmcgui

    step_ms = max(1, step_ms)
    max_loop = max(1, int(timeout_ms / step_ms))
    markers = [marker for marker in path_markers if marker]
    if not markers:
        markers = ["plugin://"]

    for _ in range(max_loop):
        xbmc.sleep(step_ms)
        if xbmcgui.getCurrentWindowId() != 10025:
            continue
        kodi_path = xbmc.getInfoLabel("Container.FolderPath") or ""
        if not any(marker in kodi_path for marker in markers):
            continue
        if xbmc.getCondVisibility("Container.IsUpdating"):
            continue
        if require_item_count:
            try:
                item_count = int(xbmc.getInfoLabel("Container.NumItems"))
            except (TypeError, ValueError):
                continue
            if item_count <= 0:
                continue
        return True
    return False


def get_clean_number(value):
    """
    De-strings stringed int/float and returns respective type
    :param value: Stringed value of an integer or float
    :type value: str
    :return: Converted int or float or None if value error
    :rtype: int, float, None
    """
    if isinstance(value, (int, float)):
        return value
    try:
        return float(value) if "." in value else int(value.replace(",", ""))
    except ValueError:
        return None


def ensure_path_is_dir(path):
    """
    Ensure provided path string will work for kodi methods involving directories
    :param path: Path to directory
    :type path: str
    :return: Formatted path
    :rtype: str
    """
    if sys.platform == "win32":
        if not path.endswith("\\"):
            if path.endswith("/"):
                path = path.rstrip("/")
            return f"{path}\\"
    elif not path.endswith("/"):
        return f"{path}/"
    return path


def safe_round(x, y=0):
    """PY2 and PY3 equal rounding, its up to 15 digits behind the comma.

    :param x: value to round
    :type x: float
    :param y: decimals behind the comma
    :type y: int
    :return: rounded value
    :rtype: float
    """
    place = 10**y
    rounded = (int(x * place + 0.5 if x >= 0 else -0.5)) / place
    if rounded == int(rounded):
        rounded = int(rounded)
    return rounded


def safe_dict_update(dictionary, value):
    """Checks the value against not valid types to update the dictionary

    :param dictionary:dictionary to update
    :type dictionary:dict
    :param value:value to update the supplied dictionary
    :type value:dict
    :return:updated dictionary
    :rtype:dict
    """
    if dictionary is None:
        return dictionary
    if value and isinstance(value, dict):
        dictionary.update(copy.deepcopy(value))
    return dictionary


def is_stub():
    """Checks if the current loaded xbmc lib is from kodistubs

    :return:True or False indicating if this is a kodistub
    :rtype:bool
    """
    return hasattr(xbmc, "__kodistubs__")


def validate_path(path):
    """Returns the translated path.

    :param path:Path to format
    :type path:str
    :return:Translated path
    :rtype:str
    """
    if hasattr(xbmcvfs, "validatePath"):
        path = xbmcvfs.validatePath(path)  # pylint: disable=no-member
    else:
        path = xbmc.validatePath(path)  # pylint: disable=no-member
    return path


def translate_path(path):
    """Validates the path against the running platform and ouputs the clean path.

    :param path:Path to be verified
    :type path:str
    :return:Verified and cleaned path
    :rtype:str
    """
    if hasattr(xbmcvfs, "translatePath"):
        path = xbmcvfs.translatePath(path)  # pylint: disable=no-member
    else:
        path = xbmc.translatePath(path)  # pylint: disable=no-member
    return path


def create_multiline_message(line1=None, line2=None, line3=None, *lines):
    """Creates a message from the supplied lines

    :param line1:Line 1
    :type line1:str
    :param line2:Line 2
    :type line2:str
    :param line3: Line3
    :type line3:str
    :param lines:List of additional lines
    :type lines:list[str]
    :return:New message wit the combined lines
    :rtype:str
    """
    result = []
    if line1:
        result.append(line1)
    if line2:
        result.append(line2)
    if line3:
        result.append(line3)
    if lines:
        result.extend(l for l in lines if l)
    return "\n".join(result)


def makedirs(name, mode=0o777, exist_ok=False):
    """makedirs(name [, mode=0o777][, exist_ok=False])

    Super-mkdir; create a leaf directory and all intermediate ones.  Works like
    mkdir, except that any intermediate path segment (not just the rightmost)
    will be created if it does not exist. If the target directory already
    exists, raise an OSError if exist_ok is False. Otherwise no exception is
    raised.  This is recursive.

    :param name:Name of the directory to be created
    :type name:str
    :param mode:Unix file mode for created directories
    :type mode:int
    :param exist_ok:Boolean to indicate whether is should raise on an exception
    :type exist_ok:bool
    """
    try:
        os.makedirs(name, mode)
    except OSError:
        if not exist_ok:
            raise


def merge_dicts(*dict_args):
    """
    Given any number of dictionaries, shallow copy and merge into a new dict,
    precedence goes to key value pairs in latter dictionaries.
    """
    result = {}
    for dictionary in dict_args:
        safe_dict_update(result, dictionary)
    return result


def filter_dictionary(dictionary, *keys):
    """Filters the dictionary with the supplied args

    :param dictionary:Dictionary to filter
    :type dictionary:dict
    :param keys:Keys to filter on
    :type keys:any
    :return:Filtered dictionary
    :rtype:dict
    """
    return {k: v for k in keys if (v := dictionary.get(k))} if dictionary else None


def safe_dict_get(dictionary, *path):
    """Safely get the value from a given path taken into account that the path can be none.

    :param dictionary:Dictionary to take the path from
    :type dictionary:dict
    :param path:Collection of items we try to get form the dict.
    :type path:str
    :return:The value for that given path
    :rtype:any
    """
    if not isinstance(dictionary, dict):
        return None
    if not path:
        return dictionary
    result = dictionary

    for element in path:
        if isinstance(result := result.get(element), dict):
            continue
        else:
            break

    result = copy.deepcopy(result)
    return result


@total_ordering
class FixedSortPositionObject:
    """
    A class that always returns equality for a comparison with any other object
    """

    def __lt__(self, other):
        return False

    def __eq__(self, other):
        return True

    def __neg__(self):
        return self
