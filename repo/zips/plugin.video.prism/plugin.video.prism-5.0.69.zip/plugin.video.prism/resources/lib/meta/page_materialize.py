"""Sync-time and prefetch page materialization (Simkl detail + provider paint + display_meta stamp)."""
from __future__ import annotations

import threading
from typing import Any

_materialize_lock = threading.Lock()
_materialize_inflight: set[str] = set()


def _materialize_dedupe_key(catalog: str, refs: list[dict]) -> str:
    ids: list[int] = []
    for ref in refs or []:
        if isinstance(ref, dict) and ref.get("simkl_id") is not None:
            ids.append(int(ref["simkl_id"]))
    ids.sort()
    return f"{catalog}:{','.join(str(i) for i in ids)}"


def _try_acquire_materialize(key: str) -> bool:
    with _materialize_lock:
        if key in _materialize_inflight:
            return False
        _materialize_inflight.add(key)
        return True


def _release_materialize(key: str) -> None:
    with _materialize_lock:
        _materialize_inflight.discard(key)


def stamp_page_rows_to_display_meta(catalog: str, rows: list[dict[str, Any]], *, profile: str = "browse") -> int:
    """Persist paint-complete rows into display_meta with trust stamps."""
    if not rows:
        return 0
    from resources.lib.meta.paint_complete import partition_paint_rows

    paint_media = "movie" if catalog == "movie" else ("anime" if catalog == "anime" else "tvshow")
    movies = [row for row in rows if isinstance(row, dict) and row.get("catalog") == "movie"]
    tv_rows = [row for row in rows if isinstance(row, dict) and row.get("catalog") == "tv"]
    anime_rows = [row for row in rows if isinstance(row, dict) and row.get("catalog") == "anime"]
    written = 0
    from resources.lib.meta.display_store import get_display_meta_store

    store = get_display_meta_store()
    if movies:
        complete, _ = partition_paint_rows(movies, "movie", profile=profile)
        if complete:
            written += store.set_stamped_rows_batch("movie", complete)
    if tv_rows:
        complete, _ = partition_paint_rows(tv_rows, "tvshow", profile=profile)
        if complete:
            written += store.set_stamped_rows_batch("tvshow", complete)
    if anime_rows:
        complete, _ = partition_paint_rows(anime_rows, "anime", profile=profile)
        if complete:
            written += store.set_stamped_rows_batch("anime", complete)
    if not movies and not tv_rows and not anime_rows and rows:
        complete, _ = partition_paint_rows(rows, paint_media, profile=profile)
        store_media = "movie" if catalog == "movie" else paint_media
        if complete:
            written += store.set_stamped_rows_batch(store_media, complete)
    return written


def materialize_browse_page_rows(
    catalog: str,
    refs: list[dict],
    rows: list[dict],
    *,
    profile: str = "browse",
    skip_detail_if_plot_ready: bool = False,
) -> list[dict]:
    """Seren sync warmup for prefetch/stamp helpers."""
    from resources.lib.pipeline.sync_page_warmup import warmup_sync_page_refs
    from resources.lib.simkl.media_ref import sync_db_rows_for_refs

    warmup_sync_page_refs(catalog, refs)
    return sync_db_rows_for_refs(catalog, refs) or rows


def materialize_refs_stamp_from_sync_db(
    catalog: str,
    refs: list[dict],
    *,
    profile: str = "browse",
) -> list[dict]:
    return materialize_browse_page_rows(catalog, refs, [], profile=profile, skip_detail_if_plot_ready=True)


def materialize_refs_from_sync_db(
    catalog: str,
    refs: list[dict],
    *,
    profile: str = "browse",
) -> list[dict]:
    return materialize_browse_page_rows(catalog, refs, [], profile=profile)


def schedule_browse_page_materialize(
    catalog: str,
    refs: list[dict],
    *,
    profile: str = "browse",
) -> None:
    """Background full-page materialize (stamps display_meta for warm re-open / scroll)."""
    if not refs:
        return

    key = _materialize_dedupe_key(catalog, refs)
    if not _try_acquire_materialize(key):
        return

    def _work() -> None:
        from resources.lib.modules.globals import g
        from resources.lib.net.request_policy import policy_from_settings

        g.ensure_addon()
        try:
            policy_from_settings().reset_menu_budget()
            materialize_refs_from_sync_db(catalog, refs, profile=profile)
        except Exception:
            g.log_stacktrace()
        finally:
            _release_materialize(key)

    if _schedule_materialize_background(_work):
        return
    _work()


def _schedule_materialize_background(work) -> bool:
    """Seren-aligned: materialize in the same invoker as list build (no background thread)."""
    return False


def schedule_browse_page_materialize_background(
    catalog: str,
    refs: list[dict],
    *,
    profile: str = "browse",
) -> None:
    """Background materialize (catalog pipeline)."""
    schedule_browse_page_materialize(catalog, refs, profile=profile)


def schedule_browse_page_stamp_background(
    catalog: str,
    refs: list[dict],
    *,
    profile: str = "browse",
) -> None:
    """After genre menu open: full art + stamps without repeating Simkl detail."""
    if not refs:
        return

    key = f"stamp:{_materialize_dedupe_key(catalog, refs)}"
    if not _try_acquire_materialize(key):
        return

    def _work() -> None:
        from resources.lib.modules.globals import g
        from resources.lib.net.request_policy import policy_from_settings

        g.ensure_addon()
        try:
            policy_from_settings().reset_menu_budget()
            materialize_refs_stamp_from_sync_db(catalog, refs, profile=profile)
        except Exception:
            g.log_stacktrace()
        finally:
            _release_materialize(key)

    if not _schedule_materialize_background(_work):
        _work()
