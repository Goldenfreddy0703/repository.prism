from difflib import SequenceMatcher

import xbmcgui

from resources.lib.common.source_utils import (
    SORT_NONE_LABEL,
    SORT_TAG_CATEGORIES,
    get_accepted_resolution_set,
    sort_tag_sub_options,
)
from resources.lib.common.tools import FixedSortPositionObject
from resources.lib.modules.catalog_profiles import ensure_migrated, resolve_catalog_from_item_information
from resources.lib.modules.globals import g


TAG_SORT_METHODS = {
    5: "videocodecsort",
    6: "hdrcodecsort",
    7: "audiocodecsort",
    8: "miscsort",
    9: "audiochannelssort",
}


class SourceSorter:
    """
    Handles sorting of sources according to users preferences
    """

    FIXED_SORT_POSITION_OBJECT = FixedSortPositionObject()

    def __init__(self, item_information, *, skip_last_release_priority=False):
        """
        Handles sorting of sources according to users preference
        """
        self.item_information = item_information
        self.skip_last_release_priority = skip_last_release_priority
        self.mediatype = self.item_information['info']['mediatype']
        ensure_migrated()
        self.catalog = resolve_catalog_from_item_information(item_information)

        # Filter settings
        self.resolution_set = get_accepted_resolution_set()
        self.disable_dv = False
        self.disable_hdr = False
        self.filter_set = self._get_filters()

        # Size filter settings
        self.enable_size_limit = g.get_int_setting("general.enablesizelimit")
        setting_mediatype = g.MEDIA_EPISODE if self.mediatype == g.MEDIA_EPISODE else g.MEDIA_MOVIE
        self.size_limit = g.get_int_setting(f"general.sizelimit.{setting_mediatype}") * 1024
        self.size_minimum = int(g.get_float_setting(f"general.sizeminimum.{setting_mediatype}") * 1024)
        self.speed_limit = g.get_float_setting("general.speedlimit", 10)
        self.speed_minimum = g.get_float_setting("general.speedminimum", 0)

        # Sort Settings
        self.quality_priorities = {"4K": 3, "1080p": 2, "720p": 1, "SD": 0}

        # Sort Methods
        self._get_sort_methods()

    def _get_filters(self):
        filter_string = g.get_setting(f"general.filters.{self.catalog}")
        current_filters = set() if filter_string is None else set(filter_string.split(","))

        # Set HR filters and remove from set before returning due to HYBRID
        self.disable_dv = "DV" in current_filters
        self.disable_hdr = "HDR" in current_filters

        return current_filters.difference({"HDR", "DV"})

    def _filter_reject_reason(self, source, max_size=None, min_size=None):
        quality = source.get("quality", "Unknown")
        if (
            quality not in self.resolution_set
            and all(part not in self.resolution_set for part in quality.split("/"))
            and quality != "Unknown"
        ):
            return "resolution", {
                "quality": quality,
                "accepted_resolutions": sorted(self.resolution_set),
            }

        info = source.get("info") or set()
        overlap = self.filter_set & info
        if overlap:
            return "info_tag", {
                "matched_tags": sorted(overlap),
                "parsed_tags": sorted(info),
                "active_tag_filters": sorted(self.filter_set),
            }

        if self.disable_dv and "DV" in info and "HYBRID" not in info:
            return "dv", {"parsed_tags": sorted(info)}
        if self.disable_hdr and "HDR" in info and "HYBRID" not in info:
            return "hdr", {"parsed_tags": sorted(info)}
        if self.disable_dv and self.disable_hdr and "HYBRID" in info:
            return "hybrid", {"parsed_tags": sorted(info)}

        if self.enable_size_limit:
            size = source.get("size", 0)
            if self.enable_size_limit == 1 and (
                (isinstance(size, (int, float)) and not max_size >= float(size) >= min_size)
                or (isinstance(size, str) and size != "Variable")
            ):
                return "size_speed", {"size": size, "min_size": min_size, "max_size": max_size}
            if self.enable_size_limit == 2 and (
                (isinstance(size, (int, float)) and not (self.size_minimum <= float(size) <= self.size_limit))
                or (isinstance(size, str) and size != "Variable")
            ):
                return "size_limit", {
                    "size": size,
                    "min_size": self.size_minimum,
                    "max_size": self.size_limit,
                }

        return None

    def filter_sources(self, source_list):
        # Iterate sources, yielding only those that are not filtered
        max_size = min_size = None
        if self.enable_size_limit == 1:
            duration = self.item_information["info"].get("duration") or (5400 if self.mediatype == "movie" else 2400)
            max_size = self.speed_limit * 0.125 * duration * 0.9
            min_size = self.speed_minimum * 0.125 * duration * 0.9

        for source in source_list:
            if self._filter_reject_reason(source, max_size=max_size, min_size=min_size):
                continue
            yield source

    def sort_sources(self, sources_list):
        """Takes in a list of sources and filters and sorts them according to Prism's sort settings

        :param sources_list: list of sources
        :type sources_list: list
        :return: sorted list of sources
        :rtype: list
        """
        if not sources_list:
            return []

        filtered_sources = list(self.filter_sources(sources_list))
        if not filtered_sources:
            response = (
                None
                if g.get_bool_runtime_setting('tempSilent')
                else xbmcgui.Dialog().yesno(g.ADDON_NAME, g.get_language_string(30474))
            )

            if response or g.get_bool_runtime_setting('tempSilent'):
                return self._sort_sources(sources_list)
            else:
                return []
        return self._sort_sources(filtered_sources)

    def _get_sort_methods(self):
        """
        Get Prism settings for sort methods
        """
        sort_methods = []
        self._tag_sort_priorities = {}
        sort_method_settings = {
            0: None,
            1: self._get_quality_sort_key,
            2: self._get_type_sort_key,
            3: self._get_debrid_priority_key,
            4: self._get_size_sort_key,
            10: self._get_audio_lang_sort_key,
            11: self._get_subtitle_sort_key,
        }

        if (
            not self.skip_last_release_priority
            and self.mediatype == g.MEDIA_EPISODE
            and g.get_bool_setting("general.lastreleasenamepriority")
        ):
            from resources.lib.simkl.ids import release_title_cache_key

            cache_key = release_title_cache_key(self.item_information["info"])
            self.last_release_name = g.get_runtime_setting(cache_key) if cache_key else None
            if self.last_release_name:
                sort_methods.append((self._get_last_release_name_sort_key, False))

        for i in range(1, 9):
            sm = g.get_int_setting(f"general.sortmethod.{self.catalog}.{i}")
            reverse = g.get_bool_setting(f"general.sortmethod.{self.catalog}.{i}.reverse")

            if sm == 0:
                break

            if sm in TAG_SORT_METHODS:
                category_key = TAG_SORT_METHODS[sm]
                self._load_tag_sort_priorities(category_key)
                handler = lambda source, cat=category_key: self._get_tag_priority_sort_key(source, cat)
                sort_methods.append((handler, reverse))
                continue

            handler = sort_method_settings.get(sm)
            if handler is None:
                break

            if handler == self._get_type_sort_key:
                self._get_type_sort_order()
            if handler == self._get_debrid_priority_key:
                self._get_debrid_sort_order()
                reverse = False
            if handler == self._get_audio_lang_sort_key:
                self._get_audio_sort_order()
            if handler == self._get_subtitle_sort_key:
                self._get_subtitle_sort_order()

            sort_methods.append((handler, reverse))

        self.sort_methods = sort_methods

    def _get_type_sort_order(self):
        """
        Get prism settings for type sort priority
        """
        type_priorities = {}
        type_priority_settings = {
            0: None,
            1: "cloud",
            2: "adaptive",
            3: "torrent",
            4: "hoster",
            5: "direct",
        }

        for i in range(1, 6):
            tp = type_priority_settings.get(g.get_int_setting(f"general.sourcetypesort.{self.catalog}.{i}"))
            if tp is None:
                break
            type_priorities[tp] = -i
        self.type_priorities = type_priorities

    def _load_tag_sort_priorities(self, category_key):
        struct_key, max_slots = SORT_TAG_CATEGORIES[category_key]
        options = sort_tag_sub_options(struct_key)
        tag_by_index = {
            index: (None if option == SORT_NONE_LABEL else option)
            for index, option in enumerate(options)
        }
        priorities = {}
        for level in range(1, max_slots + 1):
            idx = g.get_int_setting(f"general.{category_key}.{self.catalog}.{level}")
            tag = tag_by_index.get(idx)
            if tag is None:
                break
            priorities[tag] = -level
        self._tag_sort_priorities[category_key] = priorities

    def _get_tag_priority_sort_key(self, source, category_key):
        priorities = self._tag_sort_priorities.get(category_key, {})
        present = source.get("info", set()) & priorities.keys()
        return max((priorities[tag] for tag in present), default=-99)

    def _get_debrid_sort_order(self):
        """
        Get prism settings for debrid sort priority
        """
        debrid_priorities = {}
        debrid_priority_settings = {
            0: None,
            1: "premiumize",
            2: "real_debrid",
            3: "all_debrid",
            4: "torbox",
            5: "offcloud",
        }

        for i in range(1, 5):
            debridp = debrid_priority_settings.get(g.get_int_setting(f"general.debridsort.{self.catalog}.{i}"))
            if debridp is None:
                break
            debrid_priorities[debridp] = -i
        self.debrid_priorities = debrid_priorities

    def _get_audio_sort_order(self):
        """
        Get prism settings for audio language sort priority
        """
        audio_priorities = {}
        audio_priority_settings = {
            0: None,
            1: "MULTI-AUDIO",
            2: "DUAL-AUDIO",
            3: "SUB",
            4: "DUB",
        }

        for i in range(1, 5):
            audiop = audio_priority_settings.get(g.get_int_setting(f"general.audiosort.{self.catalog}.{i}"))
            if audiop is None:
                break
            audio_priorities[audiop] = -i
        self.audio_priorities = audio_priorities

    def _get_subtitle_sort_order(self):
        """
        Get prism settings for subtitle sort priority
        """
        subtitle_priorities = {}
        subtitle_priority_settings = {
            0: None,
            1: "MULTI-SUB",
        }

        for i in range(1, 2):
            subp = subtitle_priority_settings.get(g.get_int_setting(f"general.subtitlesort.{self.catalog}.{i}"))
            if subp is None:
                break
            subtitle_priorities[subp] = -i
        self.subtitle_priorities = subtitle_priorities

    def _sort_sources(self, sources_list):
        """
        Sort a source list based on sort_methods defined by settings
        All sort method key methods should return key values for *descending* sort.  If a reversed sort is required,
        reverse is specified as a boolean for the second item of each tuple in sort_methods
        :param sources_list: The list of sources to sort
        :return: The list of sorted sources
        :rtype: list
        """
        sources_list = sorted(sources_list, key=lambda s: s['release_title'])
        return sorted(sources_list, key=self._get_sort_key_tuple, reverse=True)

    def _get_sort_key_tuple(self, source):
        return tuple(-sm(source) if reverse else sm(source) for (sm, reverse) in self.sort_methods if sm)

    def _get_type_sort_key(self, source):
        return self.type_priorities.get(source.get("type"), -99)

    def _get_quality_sort_key(self, source):
        quality = source.get("quality")
        if quality is not None and '/' in quality:
            quality = quality.split('/')[0]
        return self.quality_priorities.get(quality, -99)

    def _get_debrid_priority_key(self, source):
        return self.debrid_priorities.get(source.get("debrid_provider"), self.FIXED_SORT_POSITION_OBJECT)

    def _get_size_sort_key(self, source):
        size = source.get("size", None)
        if size is None or not isinstance(size, (int, float)) or size < 0:
            size = 0
        return size

    def _load_last_release_name(self):
        from resources.lib.simkl.ids import release_title_cache_key

        cache_key = release_title_cache_key(self.item_information["info"])
        return g.get_runtime_setting(cache_key) if cache_key else None

    def apply_last_release_name_fallback(self, sources_list):
        """SequenceMatcher boost when digit reorder did not find a template match."""
        if self.mediatype != g.MEDIA_EPISODE or not g.get_bool_setting("general.lastreleasenamepriority"):
            return sources_list
        self.last_release_name = self._load_last_release_name()
        if not self.last_release_name:
            return sources_list
        return sorted(sources_list, key=self._get_last_release_name_sort_key, reverse=True)

    def _get_last_release_name_sort_key(self, source):
        sm = SequenceMatcher(None, self.last_release_name, source['release_title'], autojunk=False)
        if sm.real_quick_ratio() < 1:
            return 0
        ratio = sm.ratio()
        return 0 if ratio < 0.85 else ratio

    def _get_audio_lang_sort_key(self, source):
        present = {"MULTI-AUDIO", "DUAL-AUDIO", "SUB", "DUB"} & source.get("info", set())
        return max((self.audio_priorities.get(tag, -99) for tag in present), default=-99)

    def _get_subtitle_sort_key(self, source):
        if "MULTI-SUB" in source.get("info", set()):
            return self.subtitle_priorities.get("MULTI-SUB", -99)
        return -99
